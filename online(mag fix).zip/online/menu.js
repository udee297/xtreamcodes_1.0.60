// MAG variable
var g_mag_box=0;

var xmlHttp = new XMLHttpRequest();
var g_token=0;
var g_item=0;
var total_player_no=1000;
var g_macid;
var g_user_id;
var g_password;
var g_ch_no;
var g_video_itemid= Array();
var g_file_path;
var vlc_monitorTimerId = 0; 
var prevState = 0; 
var g_channel_no=1;
var g_channel_max_no=5;
var g_sddname="EZheo";
var g_liod="home";
var g_userid_password_exist=0;
var g_met="met";
var g_skip_value;
var g_timer;
var g_current_timestamp;
var g_dvr_timestamp=0;
var g_ech="ech";
var g_cur_sec;
var g_player="player";
var g_dvr_sec;
var g_media_type;
var g_name="E";
var Movie_Categories_tems=Array("Sports","Kids","Horro");
var g_Total_Folder_No=0;
var g_zho="Zho";
var g_sdfdd="pal";
var g_sdd="pla";
var bdvr_on;
var g_server_dvr_sec;var g_curs="R";
var g_dsd="ads";
var gdkeywork="0x1d 0xd4 0xs5 0xs7 0xf4";
var g_dsddd="dsa"
var g_kjds="yer";
var gkeywork="0x1d 0x34 0x45 0x87 0x54";
var g_subtitle_path;
var g_movie_category;
var g_ch_total_no=0;
var g_movie_total_no=0;
var g_content_name_array=Array();
var g_content_icon_path=Array();
var g_content_subtitle_path=Array();
var g_channel_dvr_flag=Array();
var g_content_icon_path=Array();
var g_ch_movie_flag=0;

// MAG variable
var stb;
var g_bWeb_Menu=1;
var Channel_Categories_tems=[];
var g_Channel_Name_items=[];
var g_Channel_Index=0;
var g_Channel_Total_Number=0;
var g_HyperLink_ID_items=[];
var g_HyperLink_ID_Index=0;
var g_HyperLink_ID_Total_Number=0;
var g_video_path;
var httpport;
var g_max_icon_column=10;
var g_max_icon_page=50;
var g_volume_no=0;
var g_Stop=0;
var g_player_timer=0;

var BrowserDetect = {
	init: function () {
		this.browser = this.searchString(this.dataBrowser) || "An unknown browser";
		this.version = this.searchVersion(navigator.userAgent)
			|| this.searchVersion(navigator.appVersion)
			|| "an unknown version";
		this.OS = this.searchString(this.dataOS) || "an unknown OS";
	},
	searchString: function (data) {
		for (var i=0;i<data.length;i++)	{
			var dataString = data[i].string;
			var dataProp = data[i].prop;
			this.versionSearchString = data[i].versionSearch || data[i].identity;
			if (dataString) {
				if (dataString.indexOf(data[i].subString) != -1)
					return data[i].identity;
			}
			else if (dataProp)
				return data[i].identity;
		}
	},
	searchVersion: function (dataString) {
		var index = dataString.indexOf(this.versionSearchString);
		if (index == -1) return;
		return parseFloat(dataString.substring(index+this.versionSearchString.length+1));
	},
	dataBrowser: [
		{
			string: navigator.userAgent,
			subString: "Chrome",
			identity: "Chrome"
		},
		{ 	string: navigator.userAgent,
			subString: "OmniWeb",
			versionSearch: "OmniWeb/",
			identity: "OmniWeb"
		},
		{
			string: navigator.vendor,
			subString: "Apple",
			identity: "Safari",
			versionSearch: "Version"
		},
		{
			prop: window.opera,
			identity: "Opera",
			versionSearch: "Version"
		},
		{
			string: navigator.vendor,
			subString: "iCab",
			identity: "iCab"
		},
		{
			string: navigator.vendor,
			subString: "KDE",
			identity: "Konqueror"
		},
		{
			string: navigator.userAgent,
			subString: "Firefox",
			identity: "Firefox"
		},
		{
			string: navigator.vendor,
			subString: "Camino",
			identity: "Camino"
		},
		{		// for newer Netscapes (6+)
			string: navigator.userAgent,
			subString: "Netscape",
			identity: "Netscape"
		},
		{
			string: navigator.userAgent,
			subString: "MSIE",
			identity: "Explorer",
			versionSearch: "MSIE"
		},
		{
			string: navigator.userAgent,
			subString: "Gecko",
			identity: "Mozilla",
			versionSearch: "rv"
		},
		{ 		// for older Netscapes (4-)
			string: navigator.userAgent,
			subString: "Mozilla",
			identity: "Netscape",
			versionSearch: "Mozilla"
		}
	],
	dataOS : [
		{
			string: navigator.platform,
			subString: "Win",
			identity: "Windows"
		},
		{
			string: navigator.platform,
			subString: "Mac",
			identity: "Mac"
		},
		{
			   string: navigator.userAgent,
			   subString: "iPhone",
			   identity: "iPhone/iPod"
	    },
		{
			string: navigator.platform,
			subString: "Linux",
			identity: "Linux"
		}
	]

};

function posX(obj) {
  var x = 0;
  if (obj.offsetParent) {
    while (obj.offsetParent) {
      x += obj.offsetLeft;
      obj = obj.offsetParent;
    }
  }
  else if (obj.y) {
    while (obj.x) {
      x += obj.x;
    }
  }
  return x;
}

function posY(obj) {
  var y = 0;
  if (obj.offsetParent) {
    while (obj.offsetParent) {
      y += obj.offsetTop;
      obj = obj.offsetParent;
    }
  }
  else if (obj.y) {
    while (obj.y) {
      y += obj.y;
    }
  }
  return y;
}
function show_underline(item)
{
  var item = document.getElementById(unescape(item));
  item.style.textDecoration="underline";

}
function close_underline(item)
{
  var item = document.getElementById(unescape(item));
  item.style.textDecoration="none";


}


function show_menu_item(item)
{
	
  var item = document.getElementById(unescape(item));
 var menu_item = document.getElementById("movie_categories_item_float");
   var i=0;
  var TempArray;
  var temp;
	var menu_item_buffer="";
	var nText_Max_Length=0;

   item.style.textDecoration="underline";

//   menu_item.style.left=posX(item)+item.offsetWidth/5;
   menu_item.style.left=posX(item);
  menu_item.style.right=posX(item)+item.offsetWidth;
   menu_item.style.top=posY(item)+item.offsetHeight;
   

   menu_item.innerHTML="";
 temp=item.innerHTML;
 TempArray=0;
  	TempArray=Movie_Categories_tems;

 if (TempArray.length>0)	
 {
 	menu_item.style.paddingTop=5;
 	menu_item.style.paddingLeft=5;
 	menu_item.style.paddingRight=5;
 	menu_item.style.paddingBottom=5;

 	

	  for (i=0;i<=TempArray.length-1;i++)
 	 {
 			menu_item_buffer=menu_item_buffer+'<tr><td onmouseover=show_underline("submenu_item_00'+i+'") '+'onmouseout=close_underline("submenu_item_00'+i+'")> '+'<p style="margin-top: 3; margin-bottom: 5">'+'<a '+'id="submenu_item_00'+i+'" '+'style="text-decoration:none" href="'+TempArray[i]+'">'+' <font face="Arial" size="1" color="#ffffff"><li style="color: #ffffff">'+TempArray[i]+'</li></font></a></td></tr>';
			if (TempArray[i].length>nText_Max_Length)
			{
				nText_Max_Length=TempArray[i].length;
			}
			
 	alert(menu_item_buffer);
			
 		//alert(nText_Max_Length);
 	 }
 	 if (nText_Max_Length<13)
 	 	menu_item.style.width="130px";
 	else
 	 	menu_item.style.width=nText_Max_Length*7+25;
		
  	 menu_item.innerHTML='<table border="0" cellpadding="0" cellspacing="0" bordercolor="#ffffff"> '+menu_item_buffer+' </table>';
  } else
  	{
  		 menu_item.style.paddingTop=0;
		 menu_item.style.paddingLeft=0;
		 menu_item.style.paddingRight=0;
		 menu_item.style.paddingBottom=0;
 	         menu_item.style.width="0px";


  	}
  	
 alert(menu_item.innerHTML);
 
}

function close_menu_item()
{
	
 /*var menu_item = document.getElementById("menu_item_float");
 menu_item.style.paddingTop=0;
 menu_item.style.paddingLeft=0;
 menu_item.style.paddingRight=0;
 menu_item.style.paddingBottom=0;
 menu_item.style.width="0px";

  menu_item.innerHTML="";
  */

}
function change_link(new_url, new_width, new_height)
{
   var menu_main= document.getElementById("menu_main");
   menu_main.innerHTML='<iframe frameborder="0" width='+new_width+' height='+new_height+' src="'+new_url+'"></iframe>';	
 
}

function find_cookie_value(keystr)
{ 
	var restring;
	var str;
	var substr1;
	var pos1, pos2;
	
	str=document.cookie;
	//alert(str);
	//alert(keystr);
	pos1=str.indexOf(keystr);
	//alert(pos1);
	subchar=str.substring(pos1+keystr.length,pos1+keystr.length+1);
	//alert(subchar);
	if (subchar==';')
	{
		//window.confirm("NULL");
		return 0;
	}else
	{
		substr1=str.substring(pos1+keystr.length+2,str.length);
		//alert(substr1);
		pos1=substr1.indexOf(']');
		restring=substr1.substring(0,pos1);
		//alert(restring);
		//window.confirm(restring);
		return restring;
	}
	
	
}
function add_cookie_value(keystr,keyvalue)
{
	document.cookie=keystr+'=['+keyvalue+']';
	//window.confirm(document.cookie);
	
}
function add_cookie_date(exdays)
{
var exdate=new Date();
exdate.setDate(exdate.getDate() + exdays);
document.cookie='expires='+exdate.toUTCString();
//alert(document.cookie);
}
function Clear_cookie()
{
	document.cookie='token'+'=';
	//document.cookie='userid'+'=';
	//document.cookie='password'+'=';
	document.cookie='dir_path'+'=';
	document.cookie='video_path'+'=';
	document.cookie='httpport'+'=';
	document.cookie='';

}

function encode64(input) {  

 var keyStr = "ABCDEFGHIJKLMNOP" +  

              "QRSTUVWXYZabcdef" +  

              "ghijklmnopqrstuv" +  

              "wxyz0123456789+/" +  

              "=";  
  // input = escape(input);  

    var output = "";  

    var chr1, chr2, chr3 = "";  

    var enc1, enc2, enc3, enc4 = "";  

    var i = 0; 
  
 
    do {  

       chr1 = input.charCodeAt(i++);  

       chr2 = input.charCodeAt(i++);  

       chr3 = input.charCodeAt(i++);  

  

       enc1 = chr1 >> 2;  

       enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);  

       enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);  

       enc4 = chr3 & 63;  

  

    /*   if (isNaN(chr2)) {  

          enc3 = enc4 = 64;  

       } else if (isNaN(chr3)) {  

          enc4 = 64;  

       }  
*/
  

       output = output +  

          keyStr.charAt(enc1) +  

          keyStr.charAt(enc2) +  

          keyStr.charAt(enc3) +  

          keyStr.charAt(enc4);  
  
       chr1 = chr2 = chr3 = "";  

       enc1 = enc2 = enc3 = enc4 = "";  

    } while (i < input.length);  

  

    return output;  

 }  
function Init_System_Setting()
{
  if (xmlHttp.readyState == 4) {
    var response= xmlHttp.responseText.split("\r\n");
    var httpport;
    var strlength;
    	strlength=response[0].length;
	httpport=response[0].slice(9,strlength);
     add_cookie_value("httpport",httpport);
    callServer_Get_Movie_Category();
   
  }
}
function streaming_port()
{
	
	  var cgi_url;
	  var l_token;
	  
  	//g_token=find_cookie_value("token");
  	//l_token=find_cookie_value("token");
  	//window.confirm(g_token);
	cgi_url = "http://"+location.hostname+":"+location.port+"/server/inquery_server_httpport?token="+escape(g_token)+"&flag="+Math.random();
//	cgi_url = "http://"+location.hostname+":"+location.port+"/server/inquery_server_httpport?token="+escape(l_token)+"&flag="+Math.random();
	//window.confirm(cgi_url);
	if (g_token!=0)
	{
		 xmlHttp.open("GET", cgi_url, true);
		 xmlHttp.onreadystatechange = Init_System_Setting;
		 xmlHttp.send(null);
	}
}
	

function login_return() {
	
	var login_msg = document.getElementById("login_msg");
	var login_area = document.getElementById("login_area");
	var login_status = parent.document.getElementById("login_status");
	var search_content = parent.document.getElementById("search_content");
	var browser_name;
	var i=0;
	var str;
	var cmanme;
	var pnae;
	var pnaename;
	var sfd='n';
	var dnsmd='ame';
	var dfdf='e';


  
//  alert(login_status.innerHTML);
  
  // alert(id_check_flag);
  
  if (xmlHttp.readyState == 4) 
  {
    var response = xmlHttp.responseText;
  // alert(response);
 	
  if (response.search("-1")>0)
    {
    	id_check_flag=0;
    	  login_status.innerHTML='<p><font face="Arial"> <font color="#FFFFFF" size="2">*** parameter error***</font>';
    } else if (response.search("-2")>0)
    {
    	
    	id_check_flag=0;
    	if (g_mag_box==0)
    	{
    	  login_status.innerHTML='<p><font face="Arial"> <font color="#FFFFFF" size="2">*** Wrong User ID or Password</font>';
    	}else
    	{
    	  
	  	 str='<div align="center"><table border="0" style="margin-top: 100" cellpadding="3" cellspacing="0">'+
		    '<tr>'+
		      '<td width="36%" align="left">'+
		        '<p align="left" style="text-indent: 40"><font face="Arial" size="3" color="#ffffff">Mac Address:</font></td>'+
		      '<center>'+
		      '<td width="64%" align="center"><font face="Arial"> <font size="3" color="#ffffff"><b>'+g_user_id+'</b></font></td>'+
		      '</tr>'+
		      '<tr>'+
		       '<td width="36%" align="left">'+
		          '<p style="text-indent: 40; margin-top: 20; margin-bottom: 30"><font face="Arial" size="3" color="#ffffff">Serial no.:</font></td>'+
		        '<td width="64%" align="center"><font face="Arial" size="3" color="#ffffff"><b>'+g_password+'</b></font></td>'+
		      '</tr>'+
		      '<tr>'+
		        '<td width="64%" align="center" colspan="2"><font face="Arial" size="5" color="#ffff00"><b>'+'Not Registered'+'</b></font></td>'+
		      '</tr>'+
		'</table></div>';
		
		menu_main.innerHTML=str;
	}
    } else if (response.search("-3")>0)
    {
    	id_check_flag=0;
    	  login_status.innerHTML='<p><font face="Arial"> <font color="#FFFFFF" size="2">*** User ID Time Expired***</font>';
    } 
    else
    {
    	dcmname='cmn'+dnsmd;	
    	cmanme=document.getElementById(dcmname);
   	//cmanme.innerHTML='<p align="left"><b><i><font size="4" color="#FFFFFF">'+g_name+g_zho+g_met+g_ech+'</font></i></b>';
   	pnaename='p'+sfd+'a'+dfdf;
   	pnae=document.getElementById(pnaename);
 	//pnae.innerHTML='<p style="text-indent: 10"><b><i><font color="#FFFF00" size="5">'+g_curs+g_dsd+' '+g_sdd+g_kjds+'</font></i></b>';
	g_token=response.slice(6,response.length-2);
  	//  document.cookie="token="+ g_token+"userid="+g_user_id+"password="+g_password+"#";
   	add_cookie_value("token",g_token);
  	add_cookie_value("userid",g_user_id);
  	add_cookie_value("password",g_password);
 	//add_cookie_date(365);
	//window.confirm("Login OK");
 	    id_check_flag=1;

	//if (g_mag_box==0)
	//{
	   	  login_status.innerHTML="<a href='javascript:void(0)' onclick=logout()>"+
	  	  '<font face="Arial" color="#ffffff" size="4">Logout</font></a>'; 
	  	  
	  	 search_content.innerHTML='<font face="Arial" size="2"> <input name="content_search_field" id="content_search_field" size="20"/></font><font face="Arial"><font size="2"></font>'+
		   '<input type="button" value="Search" onclick="javascript:search_conent();" id="hyper_search_button" name="search_conent" /></font>';
	//}
 
  /*	  menu_top.innerHTML='<table><tr><td><p align="right" style="margin-right: 20"><b><font color="#FFFFFF">'+"<a href='javascript:void(0)'"+' onclick=get_channel_link("middleware/videos/Channel")>'+
      			     '<font color="#FFFFFF" face="Arial" size="4">TV</font></a></font></b></p></td>'+
      			     '</tr></table>';
    */  			     
  	// get_channel_link("middleware/videos/Channel");
  	 streaming_port();
	 	//   callServer_Get_Foler_In_Folder();

 

  	/* BrowserDetect.init();
  	  browser_name=BrowserDetect.browser;
 	if (browser_name.search("Explorer")==0)
	{
  	  change_link("ovs.htm",900,400);
  	} else 	if (browser_name.search("Safari")==0)
  	{
  	  change_link("ovs_html5.htm",900,400);
   	} else
  	{
  	  change_link("ovs_html5.htm",900,400);
  	} */

    }
  }

}

function login(){
 var cgi_url;
 var encrypt_str;
 var userid_pass;
  //var t_user_id;
 //var t_password;
 /*
	if (g_userid_password_exist==0)
	 {
		 t_user_id = document.getElementById("user_id").value;
		 t_password = document.getElementById("password").value;
		 if ((t_user_id.length==0)&&(t_password.length==0))
		 {
			  g_user_id=find_cookie_value("userid");
		  	  g_password=find_cookie_value("password");
		  	//  alert(g_user_id);
		  	 // alert(g_password);
	  	  }else
	  	{
	  		g_user_id=t_user_id;
	  		g_password=t_password;
	  	}
  	}
  	*/
  	  	
  /*	  if ((g_user_id!=0)&&(g_password!=0))
  	  {
 		 if ((g_user_id!=t_user_id) && (t_user_id.length>0))
		 {
 		 	g_user_id=t_user_id;
		}
		 if ((g_password!=t_password)&&(t_password.length>0))
		 {
 		 	g_password=t_password;
		}
		
		
	 } 
	 */
	// document.getElementById("user_id").value=g_user_id;
	 //document.getElementById("password").value=g_password;
 	if (g_userid_password_exist==0)
	 {
	 
		 if (g_mag_box==0)
		 {
				 g_user_id = document.getElementById("user_id").value;
				 g_password = document.getElementById("password").value;
		}
  	}
// userid_pass=g_user_id+':'+g_password;
  userid_pass=g_user_id+escape(':')+g_password;
//alert(userid_pass);
 encrypt_str=encode64(userid_pass);
  	cgi_url = "http://"+location.hostname+":"+location.port+"/token/createtokenbased64?encrpty="+escape(encrypt_str)+"&flag="+Math.random();

 //alert(cgi_url);
 //login_status.innerHTML='login...';
 xmlHttp.open("GET", cgi_url, true);
 xmlHttp.onreadystatechange = login_return;
 xmlHttp.send(null);


}

function login_out_return() {
  
//var ch_up_flag=0;
  
  if (xmlHttp.readyState == 4) 
  {
    var response = xmlHttp.responseText;

         //ch_up_flag=find_cookie_value("ch_up_flag");       
         //if (ch_up_flag==1)
         //{
         //	callezserver_refresh_channel();
         //	Clear_Channel_update();
         //}
    	g_token=0;	
 	Clear_cookie();
     login_status.innerHTML="";
     menu_top.innerHTML="";
    init();

 
   }

}
function logout()
{
	var cgi_url;
  var login_status = document.getElementById("login_status");
  var videoname_text_id = document.getElementById("videoname_text");
   var confirm_msg="Logout?";
  var cookieStr;
  var firstpos;
  var endpos;
  
//	 if (confirm(confirm_msg))
//	{
    	videoname_text_id.innerHTML='';

     	g_token=find_cookie_value("token");
  	g_user_id=find_cookie_value("userid");
  	g_password=find_cookie_value("password");
 	 cgi_url = "/token/destroytoken?token="+escape(g_token)+"&userid="+escape(g_user_id)+ "&password=" + escape(g_password)+"&flag="+Math.random();
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = login_out_return;
	 xmlHttp.send(null);

//	}
}
function check_playing()
{
//	return;
	if (stb.IsPlaying()==false)
	{
		if (g_bWeb_Menu==0)
		{
			//stb.Stop();
			g_Channel_Index++;
			if (g_Channel_Index>(g_Channel_Total_Number-1))
			{
				g_Channel_Index=0;
			}
				
			//g_token=find_cookie_value("token");
			httpport=find_cookie_value("httpport");
			g_video_path="http://"+location.hostname+":"+httpport+"/"+g_Channel_Name_items[g_Channel_Index]+'?token='+g_token+':server_ip_port='+location.hostname+":"+httpport;
			//window.confirm(g_video_path);
			playstr="ffrt2 "+g_video_path;
			stb.Play(playstr);
			
			
		}
	}
}
// MAG Key Down
function getkeydown(e) {
	var nextIndex;
	var menu_obj;
	var iret;
if (g_mag_box==1)
{
	netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect")
}
ec = e.keyCode
ew = e.which
es = e.shiftKey
pat = /^(\S+)_(\S+)/
//alert(ec);
//alert(ew);
//alert(es);
//window.confirm(ec);
//window.confirm(ew);
	switch (ew)
	{
		case 13: // OK
		{	
				
			if (stb.IsPlaying()==true)
			{
				if (g_player_timer>0) clearInterval(g_player_timer);
				g_player_timer=0;
				
				stb.SetTopWin(0);
			        stb.SetPIG(0, -1, -1, -1);
				g_bWeb_Menu=1;
				//g_bWeb_Menu=g_bWeb_Menu%2;
				stb.Stop();
				callServer_Get_Channel_List();
			}else
			{
				//alert(g_HyperLink_ID_Index);
				//alert(g_menu_bar_Total_Hyper_no);
				if (g_HyperLink_ID_Index>=g_menu_bar_Total_Hyper_no)
				{
					g_bWeb_Menu=1;
					//alert(g_bWeb_Menu);
				}
			}
			break;
		}
		
		case 123: // Web
		{
			if (stb.IsPlaying()==true)
			{
				stb.Stop();
				stb.SetTopWin(0);
			}
				
			break;
		}
		case 37: // LEFT
		{
			
			if (g_bWeb_Menu==1)
			{
				//alert(g_menu_bar_Total_Hyper_no);
				//alert(g_HyperLink_ID_Index);
				if (g_HyperLink_ID_Index>0)
				{
					g_HyperLink_ID_Index--;
	 				if (g_HyperLink_ID_Index<g_menu_bar_Total_Hyper_no)
					{
						document.getElementById(g_HyperLink_ID_items[g_HyperLink_ID_Index]).focus();
					}else
					{
	 					document.getElementById(g_HyperLink_ID_items[g_HyperLink_ID_Index]).focus();
	 				}
	 			}else
				{
					g_HyperLink_ID_Index=g_HyperLink_ID_Total_Number-1;
	 				document.getElementById(g_HyperLink_ID_items[g_HyperLink_ID_Index]).focus();
				}
			}
			
			break;
		}
		case 39: // RIGHT
		{
			 if (g_bWeb_Menu==1)
			{
				//alert(g_menu_bar_Total_Hyper_no);
				//alert(g_HyperLink_ID_Index);
				if (g_HyperLink_ID_Index<(g_HyperLink_ID_Total_Number-1))
				{
					g_HyperLink_ID_Index++;
					document.getElementById(g_HyperLink_ID_items[g_HyperLink_ID_Index]).focus();
				}else
				{
					g_HyperLink_ID_Index=0;
					document.getElementById(g_HyperLink_ID_items[g_HyperLink_ID_Index]).focus();
				}
			}
				
			
			break;
		}
		case 82: // Play
		{
			if (g_video_path.length>0)
			{
				playstr="ffrt2 "+g_video_path;
				stb.Play(playstr);
			}
			break;
		}
		case 38: // UP
		{
			
			if (g_bWeb_Menu==0)
			{
				g_Channel_Index++;
				if (g_Channel_Index>(g_Channel_Total_Number-1))
				{
					g_Channel_Index=0;
				}
					
				httpport=find_cookie_value("httpport");
				g_video_path="http://"+location.hostname+":"+httpport+"/"+g_Channel_Name_items[g_Channel_Index]+'?token='+g_token+':server_ip_port='+location.hostname+":"+httpport;
				playstr="ffrt2 "+g_video_path;
				stb.Play(playstr);
				
				
			}else
			{
				//window.confirm(ew);
				if (ew==38)
				{
					//window.confirm(g_HyperLink_ID_Index);
					if (g_HyperLink_ID_Index>g_max_icon_column)
					{
						nextIndex=g_HyperLink_ID_Index-g_max_icon_column;
					}else
					{
						nextIndex=0;
					}
					g_HyperLink_ID_Index=nextIndex;
					document.getElementById(g_HyperLink_ID_items[g_HyperLink_ID_Index]).focus();
	
				}
			}
				
			break;
		}
		case 40: // Down
		{
			
			if (g_bWeb_Menu==0)
			{
				g_Channel_Index--;
				if (g_Channel_Index<0)
				{
					g_Channel_Index=g_Channel_Total_Number-1;
				}
				
				httpport=find_cookie_value("httpport");
				g_video_path="http://"+location.hostname+":"+httpport+"/"+g_Channel_Name_items[g_Channel_Index]+'?token='+g_token+':server_ip_port='+location.hostname+":"+httpport;				
				playstr="ffrt2 "+g_video_path;
				stb.Play(playstr);
			}else
			{
				//window.confirm(ew);
				if (ew==40)
				{
					//alert(g_HyperLink_ID_Index);
					if (g_HyperLink_ID_Index<g_menu_bar_Total_Hyper_no)
					{
						//window.confirm(g_HyperLink_ID_Index);
						nextIndex=g_HyperLink_ID_Index+g_menu_bar_Total_Hyper_no;
						//window.confirm(nextIndex);
					}else
					{
						//window.confirm(g_HyperLink_ID_Index);
						nextIndex=g_HyperLink_ID_Index+g_max_icon_column;
						//window.confirm(nextIndex);
					}
					
					if (nextIndex>g_HyperLink_ID_Total_Number-1)
					{
						
						nextIndex=g_HyperLink_ID_Total_Number-1;
						//window.confirm(nextIndex);
					}
					g_HyperLink_ID_Index=nextIndex;
					//window.confirm(g_HyperLink_ID_items[g_HyperLink_ID_Index]);
					document.getElementById(g_HyperLink_ID_items[g_HyperLink_ID_Index]).focus();					
				}
			}
			
			break;
		}
		case 9: //CHANNEL Button + -
		{
			if (g_bWeb_Menu==0)
			{
				if (es==false)
				{
					g_Channel_Index++;
					if (g_Channel_Index>(g_Channel_Total_Number-1))
					{
						g_Channel_Index=0;
					}
						
					httpport=find_cookie_value("httpport");
					g_video_path="http://"+location.hostname+":"+httpport+"/"+g_Channel_Name_items[g_Channel_Index]+'?token='+g_token+':server_ip_port='+location.hostname+":"+httpport;
					playstr="ffrt2 "+g_video_path;
					stb.Play(playstr);
				}
				else if (es==true)
				{
					g_Channel_Index--;
					if (g_Channel_Index<0)
					{
						g_Channel_Index=g_Channel_Total_Number-1;
					}
					
					httpport=find_cookie_value("httpport");
					g_video_path="http://"+location.hostname+":"+httpport+"/"+g_Channel_Name_items[g_Channel_Index]+'?token='+g_token+':server_ip_port='+location.hostname+":"+httpport;				
					playstr="ffrt2 "+g_video_path;
					stb.Play(playstr);
				}
			}
		}
		case 33: // Page UP
		{
			
			if (g_bWeb_Menu==1)
			{
				//window.confirm(ew);
				if (ew==33)
				{
					//window.confirm(g_HyperLink_ID_Index);
					if (g_HyperLink_ID_Index>g_max_icon_page)
					{
						nextIndex=g_HyperLink_ID_Index-g_max_icon_page;
					}else
					{
						nextIndex=0;
					}
					g_HyperLink_ID_Index=nextIndex;
					document.getElementById(g_HyperLink_ID_items[g_HyperLink_ID_Index]).focus();
				}
			}
				
			break;
		}
		case 34: // Page Down
		{
			
			if (g_bWeb_Menu==1)
			{
				//window.confirm(ew);
				if (ew==34)
				{
					//alert(g_HyperLink_ID_Index);
					if (g_HyperLink_ID_Index<g_menu_bar_Total_Hyper_no)
					{
						//window.confirm(g_HyperLink_ID_Index);
						nextIndex=g_HyperLink_ID_Index+g_menu_bar_Total_Hyper_no;
						//window.confirm(nextIndex);
					}else
					{
						//window.confirm(g_HyperLink_ID_Index);
						nextIndex=g_HyperLink_ID_Index+g_max_icon_page;
						//window.confirm(nextIndex);
					}
					
					if (nextIndex>g_HyperLink_ID_Total_Number-1)
					{
						
						nextIndex=g_HyperLink_ID_Total_Number-1;
						//window.confirm(nextIndex);
					}
					g_HyperLink_ID_Index=nextIndex;
					//window.confirm(g_HyperLink_ID_items[g_HyperLink_ID_Index]);
					document.getElementById(g_HyperLink_ID_items[g_HyperLink_ID_Index]).focus();			
				}
			}
			
			break;
		}
		case 83: // Stop
		{
			if (stb.IsPlaying()==true)
			{
				
				if (g_player_timer>0) clearInterval(g_player_timer);
				g_player_timer=0;

				stb.SetTopWin(0);
			        stb.SetPIG(0, -1, -1, -1);
				g_bWeb_Menu=1;
				//g_bWeb_Menu=g_bWeb_Menu%2;
				stb.Stop();
				callServer_Get_Channel_List();
			}
			break;
		}
		case 27: // Stop
		{
			iret=window.confirm("reboot stb?");
			if (iret==true)
			{
				stb.ExecAction('reboot');
			}
		}
		case 8: // Back
		{
			if (stb.IsPlaying()==true)
			{
				
				if (g_player_timer>0) clearInterval(g_player_timer);
				g_player_timer=0;

				stb.SetTopWin(0);
			        stb.SetPIG(0, -1, -1, -1);
				g_bWeb_Menu=1;
				//g_bWeb_Menu=g_bWeb_Menu%2;
				stb.Stop();
				callServer_Get_Channel_List();
			}
			break;
		}
		case 109: // Vol-
		{
			if (stb.IsPlaying()==true)
			{	
				g_volume_no-=10;
				if (g_volume_no<0) g_volume_no=0;
				stb.SetVolume(g_volume_no);
			}
			break;
		}	
		case 107: // Vol+
		{
			if (stb.IsPlaying()==true)
			{			
				g_volume_no+=10;
				if (g_volume_no>100) g_volume_no=100;
				stb.SetVolume(g_volume_no);
			}
			break;
		}
	}
}
function init_menu() {
	var str;
	var login_win;
	var x1, y1;
	var windowWidth;
	var windowHeight; 
	//var stb;
	var stbversion;
	var mac_id;
	
	BrowserDetect.init();
	browser_name=BrowserDetect.browser;
	os_name=BrowserDetect.OS;
	if ((browser_name.search("Safari")==0)&&(os_name.search("Linux")==0))
	{
		g_mag_box=1;
	}else
	{
		g_mag_box=0;
	}
       /* menu_main.innerHTML='<center><table border="0" style="margin-top: 100" cellpadding="0" cellspacing="0">'+
	   '<tr><td>'+
	   '<p style="text-indent: 5" ><font color="#FFFFFF" face="Arial" size="2">User ID: </font></p>'+
	   '</td>'+      
	   '<td>'+ 
	   '<p style="text-indent: 5" ><font face="Arial"> <font size="2"> <input type="text" name="user_id" id="user_id" size="20"/></font></font>'+
	   '</td>'+
	   '</tr>'+
	   '<tr>'+
	   '<td>'+
	   '<p style="text-indent: 5" style="margin-top: 15"><font color="#FFFFFF" face="Arial" size="2">Password: </font></p>'+    
	   '</td>'+ 
	   '<td> <p style="text-indent: 5" style="margin-top: 15"><font face="Arial" size="2"> <input type="password" name="password" id="password" size="20"/></font><font face="Arial"><font size="2"></font>'+
           '<input type="button" value="OK" onclick="javascript:login();" name="B1" /></font>'+
	   '</td></tr>'+
	   '</table>';
	   //Clear_cookie();
	   */
	   //g_mag_box=0;
	  if (g_mag_box==1)
	  {
		
		stb = gSTB;
		stbversion = stb.Version();
		//window.confirm(stbversion);
		//alert(stbversion);
		mac_id=stb.RDir("MACAddress");
		//alert(mac_id);
		g_user_id=mac_id.toUpperCase();
		//alert(g_user_id);
		if (g_user_id.length==18)
		{
			g_user_id=g_user_id.substring(0,g_user_id.length-1);
		}

		//g_user_id="root";
		//alert(g_user_id);
		g_password=stb.RDir("SerialNumber");
		//alert(g_password.length);
		//g_password="1234";
		//window.confirm(g_password);
	
	//stb.DeinitPlaye();
	        stb.InitPlayer();
	        stb.SetTopWin(0);
	        stb.SetAspect(0x10);
	        stb.SetWinAlphaLevel(1,255);
	        stb.SetPIG(1, -1, -1, -1);
	        //stb.SetUserFlickerControl(1);
	        stb.SetDefaultFlicker(1);
	        stb.SetLoop(0);
	        stb.GetVolume(g_volume_no);
	       // stb.SetMicVolume(100);
	 
		Clear_cookie();
		//window.confirm(g_user_id);
		login();
		//alert(g_password);
	  }else { 
		  g_user_id=find_cookie_value("userid");
	  	  g_password=find_cookie_value("password");

		  str='<div align="center"><table border="0" style="margin-top: 100" cellpadding="3" cellspacing="0">'+
		    '<tr>'+
		      '<td width="36%" align="left">'+
		        '<p align="left" style="text-indent: 40"><font face="Arial" size="3" color="#ffffff">User ID:</font></td>'+
		      '<center>'+
		      '<td width="64%" align="center"><font face="Arial"> <font size="3"> <input type="text" name="user_id" id="user_id" size="30" value='+g_user_id+'></font></td>'+
		      '</tr>'+
		      '<tr>'+
		       '<td width="36%" align="left">'+
		          '<p style="text-indent: 40; margin-top: 20; margin-bottom: 30"><font face="Arial" size="3" color="#ffffff">Password:</font></td>'+
		        '<td width="64%" align="center"><font face="Arial" size="3"> <input type="password" name="password" id="password" size="30" value='+g_password+'></font></td>'+
		      '</tr>'+
		      '<tr>'+
		        '<td width="36%" align="left"></td>'+
		      '</center>'+
		      '<td width="64%" align="center">'+
		            '<p align="right">'+
		            '<input type="button" value="Login" onclick="javascript:login();" name="B1" />&nbsp;&nbsp;'+
		            '<input type="button" value="Cancel" onclick="window.close();" name="B2" />'+
		            '</p>'+
		      '</td>'+
		    '</tr>'+
		'</table></div>';
		
		
		menu_main.innerHTML=str;

		Clear_cookie();
		g_userid_password_exist=0;
	}
}

function Get_Movie_Category()
{
	var picture_menu = document.getElementById("picture_menu");
	var str;
	var buffer;
	var i;
	var j;
	var path;
	var trstart=0;
	var strtext;
	var video_path;
	var browser_name;
	var buffer_video_text;
	var media_text;
	var media_text_path;
	var str;
	var folder_index=0;
	var cmanme;
	var pnae;
	var pnaename;
	var sfd='n';
	var dnsmd='ame';
	var dfdf='e';
 
  if (xmlHttp.readyState == 4) {
  var response = xmlHttp.responseText.split("\r\n");
   // alert(g_file_path);
     str='';
     strtext='';
  	//g_token=find_cookie_value("token");
 	if (g_token==0) return; 
 	//alert(g_token);
 	
    	dcmname='cmn'+dnsmd;	
    	cmanme=document.getElementById(dcmname);
   	cmname.innerHTML='<p align="left"><b><i><font size="4" color="#FFFFFF">'+g_name+g_zho+g_met+g_ech+'</font></i></b>';
   	pnaename='p'+sfd+'a'+dfdf;
   	pnae=document.getElementById(pnaename);
 	//pnae.innerHTML='<p style="text-indent: 10"><b><i><font color="#FFFF00" size="5">'+g_curs+g_dsd+' '+g_sdd+g_kjds+'</font></i></b>';


        for (i=0;;i++)
  	{
	//  alert(response[i]);
	    if (response[i]==0)
  	    {
  	    	break;
 	    } else
  	    {
  	    	strlength=response[i].length;
	  	folder_name=response[i].substring(9);
 	    	Movie_Categories_tems[folder_index]=folder_name; 
 	    	folder_index++;
    } 
      	}
      	g_Total_Folder_No=folder_index;
      	
      	if (g_mag_box==1)
	   {
		g_HyperLink_ID_Index=0;
		g_HyperLink_ID_Total_Number=0;
		hyperID="hyper_menu"+'TV';
		g_HyperLink_ID_items[g_HyperLink_ID_Index]=hyperID;
		current_hyper_index=g_HyperLink_ID_Index;
		g_HyperLink_ID_Index++;
		g_HyperLink_ID_Total_Number++;
		
		g_menu_bar_Total_Hyper_no=g_HyperLink_ID_Total_Number;
	        str='<table><tr><td><p><b><font color="#FFFFFF">'+"<a id="+hyperID+" href='javascript:void(0)' style='text-decoration:none'"+' onclick=callServer_Get_Channel_List()>'+
      			     '<font color="#ffffff" face="Arial" size="3">TV</font></a></font></b></p></td>';
		//alert(hyperID);
	   }else
	   {
        	str='<table><tr><td><p><b><font color="#FFFFFF">'+"<a href='javascript:void(0)' style='text-decoration:none'"+' onclick=callServer_Get_Channel_List()>'+
      			     '<font color="#ffffff" face="Arial" size="3">TV</font></a></font></b></p></td>';
      	}
    
    	j=1;
      	 for (i=0;i<g_Total_Folder_No;i++)
      	 {
      	  	
      	  	if (g_mag_box==1)
      	  	{
      	  		hyperID="hyper_menu"+i;
      			str+='<td><p style="margin-right: 5"><b><font color="#FFFFFF">'+"<a id="+hyperID+" href='javascript:void(0)' style='text-decoration:none'"+' onclick=javascript:callServer_Get_Movie_List("'+Movie_Categories_tems[i]+'")>'+
     			     '<font color="#ffffff" face="Arial" size="3">'+Movie_Categories_tems[i]+'</font></a></font></b></p>'+
       			     '</td>';
      	  		g_HyperLink_ID_items[g_HyperLink_ID_Index]=hyperID;
			g_HyperLink_ID_Index++;
			g_HyperLink_ID_Total_Number++;
		}else
		{
     			str+='<td><p style="margin-right: 5"><b><font color="#FFFFFF">'+"<a href='javascript:void(0)' style='text-decoration:none'"+' onclick=javascript:callServer_Get_Movie_List("'+Movie_Categories_tems[i]+'")>'+
     			     '<font color="#ffffff" face="Arial" size="3">'+Movie_Categories_tems[i]+'</font></a></font></b></p>'+
       			     '</td>';
 			
		}

       		j++;
       		if (j>=7)
       		{
       			str+='</tr><tr>';
       			j=0;
       		}
       		
       	}
 	menu_top.innerHTML=str+'</tr></table>';
	callServer_Get_Channel_List();
     	if (g_mag_box==1)
	   {
		
  		
  		hyperID="content_search_field";
  		g_HyperLink_ID_items[g_HyperLink_ID_Index]=hyperID;
		g_HyperLink_ID_Index++;
		g_HyperLink_ID_Total_Number++;

  		hyperID="hyper_search_button";
  		g_HyperLink_ID_items[g_HyperLink_ID_Index]=hyperID;
		g_HyperLink_ID_Index++;
		g_HyperLink_ID_Total_Number++;
		

		g_menu_bar_Total_Hyper_no=g_HyperLink_ID_Total_Number;
		//g_HyperLink_ID_Index=current_hyper_index;
		//alert(g_HyperLink_ID_items[g_HyperLink_ID_Index]);
	 	//document.getElementById(g_HyperLink_ID_items[0]).focus();

		//alert(hyperID);
	   }
       			
	//alert(menu_top.innerHTML);
    }
  	
}


function callServer_Get_Movie_Category(){
 var  cgi_url;
 var path;
 // var keyword_buffer= parent.parent.document.getElementById("keyword_buffer").innerHTML;
var home_field = parent.parent.document.getElementById("home_field");

	//home_field.innerHTML="<a href='javascript:void(0)' "+'onclick=backtovs()>'+'<font face="Arial" color="#FF0000" size="4">Home</font></a>'; 
	//path=find_cookie_value("dir_path");
	//g_file_path=path;
	//g_token=find_cookie_value("token");
 
//	alert(g_file_path);
 // cgi_url= "/cgi-bin/cgi_ezserver?get_file_list="+path+"&flag="+Math.random();
//  	 cgi_url= "/server/get_movie_category?token="+escape(g_token)+"&flag="+Math.random();
 	 cgi_url= "http://"+location.hostname+":"+location.port+"/server/get_movie_category?token="+escape(g_token)+"&flag="+Math.random();
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Get_Movie_Category;
	 xmlHttp.send(null);
}
function Get_Movie_List()
{
   var str;
   var buffer;
   var i;
   var path;
   var trstart=0;
   var strtext;
   var video_path;
   var browser_name;
   var buffer_video_text;
   var media_text;
   var media_text_path;
   var movie_name;
   var subtitle_path;
   var icon_path;
   var movie_type;
   var movie_status;
   var videoname_text_id = document.getElementById("videoname_text");
   var mv_index=0;
    var current_hyper_index;
 
 
 
  if (xmlHttp.readyState == 4) {
  var response = xmlHttp.responseText.split("\r\n");
   // alert(g_file_path);
   if (g_mag_box==1)
   {
   //	current_hyper_index=g_HyperLink_ID_Index;
	   g_HyperLink_ID_Index=g_menu_bar_Total_Hyper_no;
	   g_HyperLink_ID_Total_Number=g_menu_bar_Total_Hyper_no;
  }
      str='';
     strtext='';
  //    	  BrowserDetect.init();
  //	  browser_name=BrowserDetect.browser;
 	//g_token=find_cookie_value("token");
 	if (g_token==0) return; 
 	//alert(g_token);
	g_movie_total_no=0;

        for (i=0;;i+=5,mv_index++)
  	{
  	   //alert(response[i]);
	    if (response[i]==0)
  	    {
  	    	break;
 	    } else
  	    {
  	    	movie_name=response[i].substring(5);
  	    	g_content_name_array[g_movie_total_no]=escape(movie_name);
  	    	//alert(response[i+1]);
  	    	subtitle_path=response[i+1].substring(14);
  	    	g_content_subtitle_path[g_movie_total_no]=subtitle_path;
  	    	//alert(subtitle_path);
  	    	icon_path=response[i+2].substring(10);
  	    	//alert(icon_path);
  	    	g_content_icon_path[g_movie_total_no]=icon_path;
  	    	movie_type=response[i+3].substring(5);
  	    	//alert(movie_type);
  	    	movie_status=response[i+4].substring(7);
  	    	if (trstart==0)
  	    	{
  	    		str+='<tr>';
  	    		strtext+='<tr>';
  	    	} 
 		
		if (g_mag_box==0)
	  	{ 
	  		str+='<td width="8%" valign="middle" align="center" height="92">'+
			'<a style="text-decoration:none"'+ 
			"href='javascript:void(0)'"+
	//		' onclick=call_play_video("'+movie_name+'","'+subtitle_path+'","'+movie_type+'")>'+
			' onclick=call_play_video("'+escape(movie_name)+'","'+escape(subtitle_path)+'"'+')>'+
	//		' onclick=call_play_video("'+escape(movie_name)+'")>'+
			'<img border="0" src="'+icon_path+'" width="80" height="100"></a></td>';
			strtext+='<td width="8%" valign="middle" align="center" height="23"><font size="2" color="#ffffff" face="Arial">'+unescape(movie_name)+'</font></td>';
		}else
		{
			hyperID="hyper"+mv_index;
			//alert(icon_path);
	  		str+='<td width="8%" valign="middle" align="center" height="92">'+
			'<a id='+hyperID+' style="text-decoration:none"'+ 
			"href='javascript:void(0)'"+
	//		' onclick=call_play_video("'+movie_name+'","'+subtitle_path+'","'+movie_type+'")>'+
			' onclick=call_play_video("'+escape(movie_name)+'","'+escape(subtitle_path)+'"'+')>'+
	//		' onclick=call_play_video("'+escape(movie_name)+'")>'+
			'<img border="0" src="'+icon_path+'" width="80" height="100"></a></td>';
			strtext+='<td width="8%" valign="middle" align="center" height="23"><font size="2" color="#ffffff" face="Arial">'+unescape(movie_name)+'</font></td>';

			g_HyperLink_ID_items[g_HyperLink_ID_Index]=hyperID;
			g_HyperLink_ID_Index++;
			g_HyperLink_ID_Total_Number++;
			
		}
		//alert(str);
		g_movie_total_no++;	
		

		trstart++;
		if (trstart==10)
  	    	{
  	    		str+='</tr>';
  	    		strtext+='</tr>';
  	    		str+=strtext;
  	    		strtext='';
  	    		trstart=0;
 	    		
  	    	}
	 		//alert(str);
   	    } 
      }
  	if (trstart!=0)
 	{
 	  	    		str+='</tr>';
	  	    		strtext+='</tr>';
	  	    		str+=strtext;
	}
	if (i==0)
	{
		str='<tr><td><p align="center"><b><i><font face="Arial" color="#FFFFFF" size="5">No Content</font></i></b></p>'+
     		'</td></tr>';
	}
	videoname_text_id.innerHTML='<font face="Arial" size="2" color="#FFFF00"><b>Category: '+g_movie_category+'</b>'+' (Total: '+g_movie_total_no+')</font>';
	menu_main.innerHTML='<center><table border="0" cellpadding="0" cellspacing="0" width="100%"><p style="margin-top: 5">'+str+'</table></center>';
	if (g_mag_box==1)
	{
   		if (g_HyperLink_ID_Index>g_menu_bar_Total_Hyper_no)
     		{
	     		g_HyperLink_ID_Index=g_menu_bar_Total_Hyper_no;
	     	}else
	     	{
	     		g_HyperLink_ID_Index=0;
	     	}
	 	document.getElementById(g_HyperLink_ID_items[g_HyperLink_ID_Index]).focus();
	}

//	alert(g_HyperLink_ID_Index);
//	alert(g_HyperLink_ID_Total_Number);
	//alert(str);
// 	picture_menu.innerHTML='<center><table border="0" cellpadding="0" cellspacing="0" width="100%">'+str+'</table></center>';
   }
  	
}


function callServer_Get_Movie_List(category){
 var  cgi_url;
 var category;
 // var keyword_buffer= parent.parent.document.getElementById("keyword_buffer").innerHTML;
var home_field = parent.parent.document.getElementById("home_field");
  var prev_ch_id = document.getElementById("prev_ch");
  var next_ch_id = document.getElementById("next_ch");

	  
	   prev_ch_id.innerHTML='';
	   next_ch_id.innerHTML='';
	   
	   g_ch_movie_flag=1;

	//home_field.innerHTML="<a href='javascript:void(0)' "+'onclick=backtovs()>'+'<font face="Arial" color="#FF0000" size="4">Home</font></a>'; 
	//category=find_cookie_value("category");
	//g_token=find_cookie_value("token");
 	g_movie_category=category;
 //	alert(g_file_path);
 // cgi_url= "/cgi-bin/cgi_ezserver?get_file_list="+path+"&flag="+Math.random();
//  cgi_url= "/server/get_movie_list?token="+escape(g_token)+ "&category=" +category+ "&subtitle_type=vtt"+"&flag="+Math.random();
  cgi_url= "http://"+location.hostname+":"+location.port+"/server/get_movie_list?token="+escape(g_token)+ "&category=" +category+ "&subtitle_type=vtt"+"&flag="+Math.random();

//  alert(cgi_url);
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Get_Movie_List;
	 xmlHttp.send(null);
}

function change_movie_link(category)
{
	var vlc;
//	var keyword_buffer= parent.document.getElementById("keyword_buffer");
	var browser_name;

//	keyword_buffer.innerHTML= '<p align="center"><font color="#FFFFFF" size="3">'+path+'</font>';
	add_cookie_value("category",category);
     	menu_main.innerHTML='<iframe frameborder="0" width=100% height=800 src="'+"pictures.htm"+'"></iframe>';
 
}
function Get_Dvr_Starting_Time()
{
 if (xmlHttp.readyState == 4) {
  	var response = xmlHttp.responseText;
  	var d=new Date(response);
 //	alert(response);

  	g_server_dvr_sec=d.getTime();
  //	alert(g_server_dvr_sec);
  	
   	
  }
}
/* function sleep(ms) {
    var unixtime_ms = new Date().getTime();
    while(new Date().getTime() < unixtime_ms + ms) {}
}
*/
//function play_channel(path, ch_no,dvr_on)
function play_channel(ch_no,ch_name,dvr_on)
{
	var vlc;
	var vlc_id;
	var flash_video_window;
	var path;
	var video_path;
	var browser_name;
	var str;
	var pos1;
	var browser_name;
//	var ch_picture_menu = document.getElementById("ch_picture_menu");
	var videoname_text_id=document.getElementById("videoname_text");
	var next_ch_id=document.getElementById("next_ch");
	var prev_ch_id=document.getElementById("prev_ch");
	var  cgi_url;
	var d=new Date();
   	var httpport;
	var cmanme;
	var pnae;
	var pnaename;
	var sfd='n';
	var dnsmd='ame';
	var dfdf='e';	
	var next_ch_no;
	var prev_ch_no;
	var next_dvr_folder_on;
	var prev_dvr_folder_on;
	var os_name;
	
 	cgi_url= "/server/query_dvr_starting_time?token="+escape(g_token)+ "&ch_no=" +ch_no+"&flag="+Math.random();
	xmlHttp.open("GET", cgi_url, true);
	xmlHttp.onreadystatechange = Get_Dvr_Starting_Time;
	xmlHttp.send(null);
   	dcmname='cmn'+dnsmd;	
    	cmanme=parent.document.getElementById(dcmname);
   	//cmanme.innerHTML='<p align="left"><b><i><font size="4" color="#FFFFFF">'+g_name+g_zho+g_met+g_ech+'</font></i></b>';
   	pnaename='p'+sfd+'a'+dfdf;
   	pnae=parent.document.getElementById(pnaename);
 	//pnae.innerHTML='<p style="text-indent: 10"><b><i><font color="#FFFF00" size="5">'+g_curs+g_dsd+' '+g_sdd+g_kjds+'</font></i></b>';
	g_cur_sec=d.getTime();
	g_dvr_sec=g_cur_sec;
	videoname_text_id.innerHTML='<font face="Arial" size="2" color="#FFFF00"><b>Channel '+ch_no+': '+unescape(ch_name)+'</b></font>';
	
	if (g_mag_box==0)
	{
		next_ch_no=ch_no+1;
		if (next_ch_no>g_ch_total_no)
		{
			next_ch_no=1;
		}
		
		next_dvr_folder_on=g_channel_dvr_flag[next_ch_no];
		next_ch_name=g_content_name_array[next_ch_no-1];
		next_dvr_folder_on=g_channel_dvr_flag[next_ch_no-1];
		next_ch_id.innerHTML='<p align="left"><input type="button" value="+"'+" onclick='javascript:play_channel("+next_ch_no+',"'+unescape(next_ch_name)+'",'+next_dvr_folder_on+");'"+' name="B3" style="font-size: 14pt"/></p>';
	
		prev_ch_no=ch_no-1;
		if (prev_ch_no==0)
		{
			prev_ch_no=g_ch_total_no;
		}
		prev_ch_name=g_content_name_array[prev_ch_no-1];
		prev_dvr_folder_on=g_channel_dvr_flag[prev_ch_no-1];
		prev_ch_id.innerHTML='<p align="left"><input type="button" value="-"'+" onclick='javascript:play_channel("+prev_ch_no+',"'+unescape(prev_ch_name)+'",'+prev_dvr_folder_on+");'"+' name="B3" style="font-size: 14pt"/></p>';
	}
//	ch_picture_menu.innerHTML='<table  align="center" border="0" cellpadding="0" cellspacing="0" height="100%" width="100%">'+
	menu_main.innerHTML='<table  align="center" border="0" cellpadding="0" cellspacing="0" height="100%" width="100%">'+
              	'</center>'+
		'<tr>'+
		'<td width="100%">'+
		'<div align="center">'+
		'<table border="0" cellpadding="0" cellspacing="0" width="10%">'+
		'<tr>'+
		//'<td align="center" id=time_text_id width="12%" height="24"></td>'+
		'<td align="right" id=dvr_video_time  width="8%"></td>'+
		'<td align="center" id=backword_button_id></td>'+
		'<td align="center" id=to_live_button_id></td>'+
		'<td align="center" id=forward_button_id></td>'+
		'<td align="left" id=cur_video_time></td>'+
		'</tr>'+
		'</table>'+
		'</div>'+
		'</td>'+
		'</tr>'+
		'<center>'+

                '<tr valign="top" >'+
                '<td id="video_area" width="100%" height="100%" align="center"></td>'+
                '</tr>'+
                '</table>';
	
	g_dvr_timestamp=0;
	bdvr_on=0;
	//g_token=find_cookie_value("token");
	httpport=find_cookie_value("httpport");

 // 	video_path="http://"+location.host+path+'?token='+g_token;
 	if (g_mag_box==0)
 	{
   		video_path="http://"+location.hostname+":"+httpport+"/ch"+ch_no+".flv"+'?token='+g_token+':server_ip_port='+location.hostname+":"+httpport;
   	}else
   	{
   		video_path="http://"+location.hostname+":"+httpport+"/"+ch_no+".ch"+'?token='+g_token+':server_ip_port='+location.hostname+":"+httpport;
   	}
  // 	window.confirm(video_path);
 	g_video_path=video_path;
 	//window.confirm(g_video_path);
 	g_ch_no=ch_no;
 	//window.confirm(g_ch_no);
 	//alert(video_path);
 	if (g_mag_box==0)
 	{
	 	BrowserDetect.init();
		browser_name=BrowserDetect.browser;
		os_name=BrowserDetect.OS;
		//alert(os_name);
		//alert(browser_name);
		if (browser_name.search("Safari")==0)
		{
				//video_path=video_path.substring(0,video_path.length-4)+"muxer=ts";
				//alert(video_path);
				video_path="http://"+location.hostname+":"+httpport+"/ch"+ch_no+".m3u8"+'?token='+g_token+':server_ip_port='+location.hostname+":"+httpport;
				str='<video width="100%" height="100%" src="'+video_path+'" controls autoplay>';
		}else if ((browser_name.search("Explorer")==0) || ((browser_name.search("Chrome")==0))&&((os_name.search("Windows")==0)||(os_name.search("Linux")==0)))
		{
				video_path="http://"+location.hostname+":"+httpport+"/ch"+ch_no+".flv"+'?token='+g_token+':server_ip_port='+location.hostname+":"+httpport+"muxer=flv";
 				str='<object width="100%" height="100%">'+
				'<param name="allowFullScreen" value="true" />'+
				'<param name="allowscriptaccess" value="always" />'+
				'<embed src="/flash_player10_1/StrobeMediaPlayback.swf" type="application/x-shockwave-flash" width="100%" height="100%" allowscriptaccess="always" allowfullscreen="true" flashvars="src='+video_path+"&muxer=flv"+'&autoPlay=true">'+ 
				'</embed>'+
				'</object>';
					
			//	video_path="http://"+location.hostname+":"+httpport+"/ch"+ch_no+".m3u8"+'?token='+g_token+':server_ip_port='+location.hostname+":"+httpport;
			//	str='<video width="100%" height="100%" src="'+video_path+'" controls autoplay>';
		 	//	window.open(video_path,"_self"); 
		
	
		}else if (browser_name.search("Firefox")==0)
		{
				str='<embed type="application/x-vlc-plugin" width="100%" height="100%" name="player" autoplay="yes" loop="no" '+
				'target="'+video_path+'">';
	
		}else
		{
				video_path="http://"+location.hostname+":"+httpport+"/ch"+ch_no+".m3u8"+'?token='+g_token+':server_ip_port='+location.hostname+":"+httpport;
				str='<video width="100%" height="100%" src="'+video_path+'" controls autoplay>';
		}
		
		
				
		
	
		
		 //time_text_id.innerHTML='<font face="Arial" size="2" color="#FFFF00"><b>Current Time: </b></font>';
		if (dvr_on)
		{
			//bdvr_on=1;
			backword_button_id.innerHTML='<p align="right"><input type="button" value="<<" onclick="javascript:dvr_for_backward(0);" name="B1" /></p>';
			to_live_button_id.innerHTML='<p align="center"><input type="button" disabled value="To Live" onclick="javascript:dvr_to_live();" name="B2" /></p>';
			forward_button_id.innerHTML='<p align="left"><input type="button" disabled value=">>" onclick="javascript:dvr_for_backward(1);" name="B3" /></p>';
		}else
			{
				backword_button_id.innerHTML='';
				forward_button_id.innerHTML='';
				to_live_button_id.innerHTML='';
				cur_video_time.innerHTML='';
			}
			
		//g_current_timestamp=0;
		g_timer=setInterval(function(){show_drv_time_cur_time(0)},1000);
	
		//flash_video_window=document.getElementById("flash_video_window");
	
		//alert(str);
		video_area.innerHTML=str;
	}else
	{
		if (g_bWeb_Menu==1)
		{
			g_bWeb_Menu=0;
			stb.SetTopWin(1);
			stb.SetAspect(1);			
			g_Channel_Index=ch_no-1;
			
			playstr="ffrt2 "+g_video_path;
			//stb.SetViewport(300,300,0,0); 
			// Set video screen width, height, left, top
			//stb.Rotate(90);
			stb.Play(playstr);
		        g_player_timer=setInterval(function(){check_playing()},10*1000);

			
			/*for (;;)
			{
				if (stb.IsPlaying()==true)
				{
					sleep(5000);
					
					if (g_Stop==1) break;
					window.confirm("1111111");
				}else
				{
					g_Channel_Index++;
					if (g_Channel_Index>(g_Channel_Total_Number-1))
					{
						g_Channel_Index=0;
					}
					g_video_path="http://"+location.hostname+":"+httpport+"/"+g_Channel_Name_items[g_Channel_Index]+'?token='+g_token+':server_ip_port='+location.hostname+":"+httpport;
					//window.confirm(g_video_path);
					playstr="ffrt2 "+g_video_path;
					//stb.InitPlayer();
					stb.Play(playstr);
					
				}
			}
			*/


		}

	}
	
	
	
}
function Get_Channel_List()
{
 // var picture_menu = document.getElementById("picture_menu");
var videoname_text_id = parent.parent.document.getElementById("videoname_text");
   var str;
   var buffer;
   var i;
   var path;
   var trstart=0;
   var strtext;
   var video_path;
   var browser_name;
   var buffer_video_text;
   var media_text;
   var media_text_path;
     var ch_no;
    var ch_name;
    var ch_src;
   var ch_type;
     var dvr_folder_on=0;
	var hyperID;
     var current_hyper_index;
     var ch_index=0;

 
  if (xmlHttp.readyState == 4) {
  var response = xmlHttp.responseText.split("\r\n");
   // alert(g_file_path);
  if (g_mag_box==1)
   {
	   g_HyperLink_ID_Index=g_menu_bar_Total_Hyper_no;
	   g_HyperLink_ID_Total_Number=g_menu_bar_Total_Hyper_no;
   }

     str='';
     strtext='';
      	  BrowserDetect.init();
  	  browser_name=BrowserDetect.browser;
 	//g_token=find_cookie_value("token");
 	//alert(g_token);
	if (g_token==0) return; 
	g_ch_total_no=0;


        for (i=0,ch_index=0;;i=i+8,ch_index++)
  	{
	//  alert(response[i]);
	    if (response[i]==0)
  	    {
  	    	break;
 	    } else
  	    {
 	 	strlength=response[i].length;
	 //	alert(strlength);
   	    	ch_no=response[i].slice(3,strlength);
   	    	//alert(ch_no);
     	 	strlength=response[i+1].length;
   	    	ch_name=response[i+1].slice(5,strlength);
   	    	g_content_name_array[g_ch_total_no]=escape(ch_name);
   	    	//alert(g_content_name_array[g_ch_total_no]);
     	 	strlength=response[i+2].length;
   	    	ch_src=response[i+2].slice(4,strlength);
   	    	//alert(ch_src);
     	 	strlength=response[i+3].length;
   	    	picture_path=response[i+3].slice(11,strlength);
    	    	g_content_icon_path[g_ch_total_no]=picture_path;
 	    	//alert(picture_path);
     	 	strlength=response[i+5].length;
   	    	ch_type=response[i+5].slice(5,strlength);
  	    	//picture_path='/'+g_file_path.replace("videos","pictures")+'/ch'+ch_no+'.jpg';
//	  	media_text_path='/'+g_file_path.replace("videos","text")+'/ch'+ch_no+'.htm';
	    	if (trstart==0)
  	    	{
  	    		str+='<tr>';
  	    		strtext+='<tr>';
  	    	} 
  		if (ch_type.search("dvr")>=0)
   	    	{
   	    		dvr_folder_on=1;
   	    	}else
   	    	{
   	    		dvr_folder_on=0;
   	    	}
   	    	g_channel_dvr_flag[g_ch_total_no]=dvr_folder_on;
    	    	
		if (browser_name.search("Safari")==0)
		{
  	    		path='/ch'+ch_no+'.m3u8';
  	    	}else
  	    	{
  	    		path='/ch'+ch_no+'.flv';
  	    	}  	    	
   	    	/*
 		if (ch_src.search("rtmp")==0)
  	    	{
 			if (browser_name.search("Safari")==0)
  			{
	  	    		path='/ch'+ch_no+'.m3u8';
	  	    	}else
	  	    	{
	  	    		path='/ch'+ch_no+'.flv';
	  	    	}  	    	
	  	    	
	  	} else
  		{
  			if (browser_name.search("Safari")==0)
  			{
	  	    		path='/ch'+ch_no+'.m3u8';
	  	    	}else
	  	    	{
	  	    		path='/'+ch_no+'.ch';
	  	    	}  	    	
		}
		*/
	  	if (g_mag_box==0)
	  	{ 
			str+='<td width="8%" valign="middle" align="center" height="92">'+
			'<a style="text-decoration:none"'+ 
			"href='javascript:void(0)'"+
			' onclick=play_channel('+ch_no+',"'+escape(ch_name)+'",'+dvr_folder_on+')>'+
			'<img border="0" src="'+picture_path+'" width="80" height="100"></a></td>';
			strtext+='<td width="8%" valign="middle" align="center" height="23"><font size="2" color="#ffffff" face="Arail">'+unescape(ch_name)+'</font></td>';
		}else
		{
			g_Channel_Name_items[ch_index]=escape(ch_name);
   	    		g_Channel_Total_Number++;
	  	  	hyperID="hyper"+ch_index;
			str+='<td width="8%" valign="middle" align="center" height="92">'+
			'<a id='+hyperID+' style="text-decoration:none"'+ 
			"href='javascript:void(0)'"+
			' onclick=play_channel('+ch_no+',"'+escape(ch_name)+'",'+dvr_folder_on+')>'+
			'<img border="0" src="'+picture_path+'" width="80" height="100"></a></td>';
			strtext+='<td width="8%" valign="middle" align="center" height="23"><font size="2" color="#ffffff" face="Arail">'+unescape(ch_name)+'</font></td>';
		
			g_HyperLink_ID_items[g_HyperLink_ID_Index]=hyperID;
			g_HyperLink_ID_Index++;
			g_HyperLink_ID_Total_Number++;
		}
 	

		trstart++;
		if (trstart==10)
  	    	{
  	    		str+='</tr>';
  	    		strtext+='</tr>';
  	    		str+=strtext;
  	    		strtext='';
  	    		trstart=0;
 	    		
  	    	}
 		//alert(str);
 		g_ch_total_no++;
 		
  	    } 
      }
  	if (trstart!=0)
 	{
 	  	    		str+='</tr>';
	  	    		strtext+='</tr>';
	  	    		str+=strtext;
	}
 //	ch_picture_menu.innerHTML='<center><table border="0" cellpadding="0" cellspacing="0" width="100%">'+str+'</table></center>';
  	videoname_text_id.innerHTML='<font face="Arial" size="2" color="#FFFF00"><b>TV</b> (Total: '+g_ch_total_no+')</font>';
	menu_main.innerHTML='<center><table border="0" cellpadding="0" cellspacing="0" width="100%"><p style="margin-top: 5">'+str+'</table></center>';
     //alert(menu_main.innerHTML);
     //  title_text.innerHTML= '<p align="center"><font size="3">'+g_file_path+'</font>'
     	if (g_mag_box==1)
     	{
     		if (g_HyperLink_ID_Index>g_menu_bar_Total_Hyper_no)
     		{
	     		g_HyperLink_ID_Index=g_menu_bar_Total_Hyper_no;
	     	}else
	     	{
	     		g_HyperLink_ID_Index=0;
	     	}
	     	//alert(g_HyperLink_ID_items[g_HyperLink_ID_Index]);
	 	document.getElementById(g_HyperLink_ID_items[g_HyperLink_ID_Index]).focus();
	 	//alert(g_HyperLink_ID_Index);
 	}
 
   }
  	
}
function callServer_Get_Channel_List(){
 var  cgi_url;
 var path;
 // var keyword_buffer= parent.parent.document.getElementById("keyword_buffer").innerHTML;
var home_field = parent.parent.document.getElementById("home_field");

	g_ch_movie_flag=0;

	if (g_timer>0) clearInterval(g_timer);



	//home_field.innerHTML="<a href='javascript:void(0)' "+'onclick=backtovs()>'+'<font face="Arial" color="#FF0000" size="4">Home</font></a>'; 
	//path=find_cookie_value("dir_path");
	//g_token=find_cookie_value("token");
  
	//g_file_path=path;
	//alert(g_file_path);
 // cgi_url= "/cgi-bin/cgi_ezserver?get_file_list="+path+"&flag="+Math.random();
  //cgi_url= "/server/get_folder_filelist?token="+escape(g_token)+ "&path=" +path+"&flag="+Math.random();
//	cgi_url = "/server/app_get_channel_list?token="+escape(g_token)+"&flag="+Math.random();
//	cgi_url = "/server/query_channel_list?token="+escape(g_token)+"&flag="+Math.random();
	cgi_url = "http://"+location.hostname+":"+location.port+"/server/query_channel_list?token="+escape(g_token)+"&flag="+Math.random();
	//window.confirm(cgi_url);
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Get_Channel_List;
	 xmlHttp.send(null);
}
function get_channel_link(path)
{
	var vlc;
//	var keyword_buffer= parent.document.getElementById("keyword_buffer");
	var browser_name;

//	keyword_buffer.innerHTML= '<p align="center"><font color="#FFFFFF" size="3">'+path+'</font>';
	//add_cookie_value("dir_path",path);
     	menu_main.innerHTML='<iframe frameborder="0" width=100% height=800 src="'+"ch_pictures.htm"+'"></iframe>';
 
}
function search_conent()
{
  var search_text_id = document.getElementById("content_search_field");
   var str;
   var buffer;
   var i;
   var path;
   var trstart=0;
   var strtext;
   var video_path;
   var browser_name;
   var buffer_video_text;
   var media_text;
   var media_text_path;
     var ch_no=1;
    var ch_name;
    var ch_src;
   var ch_type;
     var dvr_folder_on=0;
     var search_text=escape(search_text_id.value);
     var not_found_flag=0;
     var iret=0;
     var ch_index=0;
     var mv_index=0;
  
   if (g_mag_box==1)
   {
  // 	current_hyper_index=g_HyperLink_ID_Index;
	   g_HyperLink_ID_Index=g_menu_bar_Total_Hyper_no;
	   g_HyperLink_ID_Total_Number=g_menu_bar_Total_Hyper_no;
   }	
    //alert(search_text);
       str='';
     strtext='';
      	  BrowserDetect.init();
  	  browser_name=BrowserDetect.browser;
 	//g_token=find_cookie_value("token");
 	//alert(g_token);
	//if (g_token==0) return; 

	if (g_ch_movie_flag==0)
	{
	        for (i=0;i<g_ch_total_no;i++,ch_index++)
	  	{
	
	 
	   	    	ch_name=g_content_name_array[i];
	   	    	//alert(ch_name);
	   	    	if (ch_name.search(search_text)>-1)
	   	    	{
	   	    		not_found_flag=1;
	   	    		//alert("Found");
		    	    	picture_path=g_content_icon_path[i];
		     	    	dvr_folder_on=g_channel_dvr_flag[i];
			    	if (trstart==0)
		  	    	{
		  	    		str+='<tr>';
		  	    		strtext+='<tr>';
		  	    	} 
		 		if (browser_name.search("Safari")==0)
				{
		  	    		path='/ch'+ch_no+'.m3u8';
		  	    	}else
		  	    	{
		  	    		path='/ch'+ch_no+'.flv';
		  	    	}  	    	
		   
			  	 ch_no=i+1;
			  	 if (g_mag_box==0)
			  	 {
					str+='<td width="16%" valign="middle" align="center" height="185">'+
					'<a style="text-decoration:none"'+ 
					"href='javascript:void(0)'"+
					' onclick=play_channel('+ch_no+',"'+ch_name+'",'+dvr_folder_on+')>'+
					'<img border="0" src="'+picture_path+'" width="150" height="213"></a></td>';
					strtext+='<td width="16%" valign="middle" align="center" height="23"><font size="2" color="#ffffff" face="Arail">'+unescape(ch_name)+'</font></td>';
				}else
				{
					hyperID="hyper"+ch_index;
					str+='<td width="16%" valign="middle" align="center" height="185">'+
					'<a id='+hyperID+' style="text-decoration:none"'+ 
					"href='javascript:void(0)'"+
					' onclick=play_channel('+ch_no+',"'+ch_name+'",'+dvr_folder_on+')>'+
					'<img border="0" src="'+picture_path+'" width="150" height="213"></a></td>';
					strtext+='<td width="16%" valign="middle" align="center" height="23"><font size="2" color="#ffffff" face="Arail">'+unescape(ch_name)+'</font></td>';
					g_HyperLink_ID_items[g_HyperLink_ID_Index]=hyperID;
					g_HyperLink_ID_Index++;
					g_HyperLink_ID_Total_Number++;
				}
		
		 	
		
				trstart++;
				if (trstart==5)
		  	    	{
		  	    		str+='</tr>';
		  	    		strtext+='</tr>';
		  	    		str+=strtext;
		  	    		strtext='';
		  	    		trstart=0;
		 	    		
		  	    	}
	 		
	  	 	} 
	  	 }
	     
	  	if (trstart!=0)
	 	{
	 	  	    		str+='</tr>';
		  	    		strtext+='</tr>';
		  	    		str+=strtext;
		}
	}else if (g_ch_movie_flag==1)
	{
		//alert(search_text);
		for (i=0;i<g_movie_total_no;i++,mv_index++)
	  	{
	  
	  	    	movie_name=g_content_name_array[i];
	  	   
	  	    	
	  	    	if (movie_name.search(search_text)>-1)
	  	    	{
		  	    	//alert(movie_name);
		  	    	//alert(response[i+1]);
		  	    	not_found_flag=1;
		  	    	subtitle_path=g_content_subtitle_path[i];
		  	    	//alert(subtitle_path);
		  	    	icon_path=g_content_icon_path[i];
		  	    	
		  	    	
		  	    	if (trstart==0)
		  	    	{
		  	    		str+='<tr>';
		  	    		strtext+='<tr>';
		  	    	} 
		 		
				if (g_mag_box==0)
				{
					str+='<td width="16%" valign="middle" align="center" height="185">'+
					'<a style="text-decoration:none"'+ 
					"href='javascript:void(0)'"+
			//		' onclick=call_play_video("'+movie_name+'","'+subtitle_path+'","'+movie_type+'")>'+
					' onclick=call_play_video("'+movie_name+'","'+escape(subtitle_path)+'"'+')>'+
			//		' onclick=call_play_video("'+escape(movie_name)+'")>'+
					'<img border="0" src="'+icon_path+'" width="140" height="200"></a></td>';
					strtext+='<td width="16%" valign="middle" align="center" height="23"><font size="2" color="#ffffff" face="Arial">'+unescape(movie_name)+'</font></td>';
				}else
				{
					hyperID="hyper"+mv_index;
					str+='<td width="16%" valign="middle" align="center" height="185">'+
					'<a id='+hyperID+' style="text-decoration:none"'+ 
					"href='javascript:void(0)'"+
			//		' onclick=call_play_video("'+movie_name+'","'+subtitle_path+'","'+movie_type+'")>'+
					' onclick=call_play_video("'+movie_name+'","'+escape(subtitle_path)+'"'+')>'+
			//		' onclick=call_play_video("'+escape(movie_name)+'")>'+
					'<img border="0" src="'+icon_path+'" width="140" height="200"></a></td>';
					strtext+='<td width="16%" valign="middle" align="center" height="23"><font size="2" color="#ffffff" face="Arial">'+unescape(movie_name)+'</font></td>';
					g_HyperLink_ID_items[g_HyperLink_ID_Index]=hyperID;
					g_HyperLink_ID_Index++;
					g_HyperLink_ID_Total_Number++;
				}
		
				
		
				trstart++;
				if (trstart==6)
		  	    	{
		  	    		str+='</tr>';
		  	    		strtext+='</tr>';
		  	    		str+=strtext;
		  	    		strtext='';
		  	    		trstart=0;
		 	    		
		  	    	}
			 		//alert(str);
		   	    } 
	   	    }
	     
	  	if (trstart!=0)
	 	{
	 	  	    		str+='</tr>';
		  	    		strtext+='</tr>';
		  	    		str+=strtext;
		}
		
	}
	
 //	ch_picture_menu.innerHTML='<center><table border="0" cellpadding="0" cellspacing="0" width="100%">'+str+'</table></center>';
 
	if (not_found_flag==1)
 	{
 		menu_main.innerHTML='<center><table border="0" cellpadding="0" cellspacing="0" width="100%">'+str+'</table></center>';
	 	if (g_mag_box==1)
		{
	   		if (g_HyperLink_ID_Index>g_menu_bar_Total_Hyper_no)
	     		{
		     		g_HyperLink_ID_Index=g_menu_bar_Total_Hyper_no;
		     	}else
		     	{
		     		g_HyperLink_ID_Index=0;
		     	}
		 	document.getElementById(g_HyperLink_ID_items[g_HyperLink_ID_Index]).focus();
		}
 	} else
	{
		str='<p><font size="3" color="#ffffff" face="Arial">Not Found</font></p>';
 		menu_main.innerHTML='<center><table border="0" cellpadding="0" cellspacing="0" width="100%">'+str+'</table></center>';
//		alert("Not Found");
	}
      //alert(menu_main.innerHTML);
     //  title_text.innerHTML= '<p align="center"><font size="3">'+g_file_path+'</font>'
  
  	
}
function play_video()
{
 //  var v_url= parent.parent.document.getElementById("v_url");
 //  var menu_main= parent.document.getElementById("menu_main");
   var path;
   var strlength;
   var ezserver_ip_path;
   var pos;
   var str;
	var httpport;

   	if (xmlHttp.readyState == 4) 
	{
		var response = xmlHttp.responseText;
		strlength=response.length;
//Windows and Linux difference	 
		strlength-=2;
//Windows and Linux difference	 
		//alert(response);
//		ezserver_ip_path=response.slice(0,strlength);

		//alert(httpport);
		httpport=find_cookie_value("httpport");
		ezserver_ip_path="http://"+location.hostname+":"+httpport;
		//alert(ezserver_ip_path);
//alert(ezserver_ip_path);
/*		pos=g_video_path.search("/Channel/");
		//alert(g_video_path);
		if (pos>0)
		{
			str=g_video_path.substring(pos+9,g_video_path.length);
//			path=ezserver_ip_path+'/'+str;
			path=ezserver_ip_path+str;
		}else
		{
			path=ezserver_ip_path+'/'+g_video_path;
//			path=ezserver_ip_path+g_video_path;
		}
*/
		path=ezserver_ip_path+'/'+g_video_path;
		//alert(path);
	  	add_cookie_value("video_path",path);
	  	add_cookie_value("subtitle_path",g_subtitle_path);
	  	
	  	add_cookie_value("media_path",g_media_type);
	  	//window.confirm(path);
	  	init_video(path,g_subtitle_path,g_media_type);
   		//menu_main.innerHTML='<iframe frameborder="0" width=99.8% height=800 src="'+"video.htm"+'"></iframe>';

	}

}

function call_play_video(path,subtitle_path)
{
	var videoname_text_id= parent.document.getElementById("videoname_text");
 
	g_video_path=unescape(path);
	g_subtitle_path=subtitle_path;

	videoname_text_id.innerHTML='<font face="Arial" size="2" color="#FFFF00"><b>'+unescape(path)+' ('+g_movie_category+')'+'</b></font>';

	g_media_type="mp4";
		
    	//var url = "/cgi-bin/cgi_ezserver?http_server_ip_port_inquery"+"&flag="+Math.random();
 //  	cgi_url= "/server/inquery_server_ip_htpport?token="+escape(g_token)+"&flag="+Math.random();
  	cgi_url= "http://"+location.hostname+":"+location.port+"/server/inquery_server_ip_httpport?token="+escape(g_token)+"&flag="+Math.random();
  	//alert(cgi_url);
	xmlHttp.open("GET", cgi_url, true);
	xmlHttp.onreadystatechange =play_video ;
	xmlHttp.send(null);

 

}


function call_show_text(path)
{
 
     var menu_text= parent.document.getElementById("menu_text");
   //  alert(path);

//  menu_text.innerHTML='<iframe frameborder="0" width=99.8% height=800 src="'+path+'"></iframe>';


 

}
function video_control_init() {
  // 1. Check for video support
 //alert("11111");
  if( !document.createElement('video').canPlayType ) return;
  // 2. Get all video containers on the page
  //alert("2222");
  var videos = document.querySelectorAll( 'div.video' ),
  videosLength = videos.length;
  // 3. Get every single video instance
  for( var i=0; i < videosLength; i++ ) {
    var root = videos[i];
    // 4. Get and create all needed elements
    video = root.querySelector( 'video' ),
    play = document.createElement( 'button' ),
    mute = document.createElement( 'button' );
    // 5. Turn off native video controls
    video.controls = false;
    // 6. Customise Play button behaviour
    play.innerHTML = play.title = 'Play';
    play.onclick = function() {
      if( video.paused ) {
        video.play();
        play.innerHTML = play.title = 'Pause';
      } else {
        video.pause();
        play.innerHTML = play.title = 'Play';
      }
    }
    // 7. Customise Mute button behaviour
    mute.innerHTML = mute.title = 'Mute';
    mute.onclick = function() {
      if( video.muted ) {
        video.muted = false;
        mute.innerHTML = mute.title = 'Mute';
      } else {
        video.muted = true;
        mute.innerHTML = mute.title = 'Unmute';
      }
    }
    // 8. Add custom controls to the video container
    root.appendChild( play );
    root.appendChild( mute );
  }
}

function show_drv_time_cur_time(timestamp)
{
	var cur_video_time=document.getElementById("cur_video_time");
	var dvr_video_time=document.getElementById("dvr_video_time");
	var d=new Date();
	
	var cur_sec=d.getTime();
//	alert(cur_sec);
	var cur_hours=d.getHours();
	var cur_minutes=d.getMinutes();
	var cur_seconds=d.getSeconds();
	var cur_time;

	var dvr_sec;
	var dvr_d;
	var dvr_hours;
	var dvr_minutes;
	var dvr_seconds;
	var dvr_time;
	g_cur_sec=cur_sec;

	g_dvr_sec+=1000;
	//dvr_sec=cur_sec-(g_current_timestamp-g_dvr_timestamp);
	dvr_d=new Date(g_dvr_sec);
	dvr_hours=dvr_d.getHours();
	dvr_minutes=dvr_d.getMinutes();
	dvr_seconds=dvr_d.getSeconds();
	
	
	cur_time= (cur_hours < 10 ? "0" + cur_hours : cur_hours) + ":" + (cur_minutes < 10 ? "0" + cur_minutes : cur_minutes) + ":" + (cur_seconds  < 10 ? "0" + cur_seconds : cur_seconds);
	if (bdvr_on)
	{
		cur_video_time.innerHTML='<p align="right"><font face="Arial" size="2" color="#FFFFFF">'+cur_time+'</font>';
	
	

	dvr_time= (dvr_hours < 10 ? "0" + dvr_hours : dvr_hours) + ":" + (dvr_minutes < 10 ? "0" + dvr_minutes : dvr_minutes) + ":" + (dvr_seconds  < 10 ? "0" + dvr_seconds : dvr_seconds);
	dvr_video_time.innerHTML='<font face="Arial" size="2" color="#FFFFFF">'+dvr_time+'</font>';
	}
	//g_current_timestamp+=1000;
	//g_dvr_timestamp+=1000;

}

function init_video(path,subtitle_path, media_path)
{
	var video_window;
	var path;
	var subtitle_path;
	var video_path;
	var browser_name;
	var str;
	var pos1;
	var browser_name;
	var backid=document.getElementById("back");
	var flashMovie;
	var soundlevel = 10;
	var backword_button_id=document.getElementById("backword_button_id");
	var forward_button_id=document.getElementById("forward_button_id");
	//var time_text_id=document.getElementById("time_text_id");
	var media_path;
	
//	video_path=path.substring(43,path.length-11)+'?u=root&p=1234';
	g_current_timestamp=0;
	g_dvr_timestamp=0;
	bdvr_on=0;
	
	//alert(path);
  //	path=find_cookie_value("video_path");
  //	subtitle_path=find_cookie_value("subtitle_path");
  //	media_path=find_cookie_value("media_path");
  	
  	menu_main.innerHTML='<table  align="center" border="0" cellpadding="0" cellspacing="0" height="100%" width="100%">'+
               	'</center>'+
		'<tr>'+
		'<td width="100%">'+
		'<div align="center">'+
		'<table border="0" cellpadding="0" cellspacing="0" width="75%">'+
		'<tr>'+
		'</tr>'+
		'</table>'+
		'</div>'+
		'</td>'+
		'</tr>'+
		'<center>'+

                '<tr valign="top" >'+
                '<td id="video_area" width="100%" height="100%" align="center"></td>'+
                '</tr>'+
                '</table>';	
  	
	//alert(path);
 	//g_user_id=find_cookie_value("userid");
  	//g_password=find_cookie_value("password");

  	//video_path=path+'?u='+g_user_id+':p='+g_password;
	//g_token=find_cookie_value("token");
	//alert(media_path)
  	video_path=path+'?token='+g_token+'&type.'+media_path;
  	//window.confirm(video_path);
 //alert(video_path);
 /*
 	if (video_path.search("flv")>0)
	{
	// Adobe Player  	
			str='<param name="allowFullScreen" value="true"></param>'+
			'<param name="allowscriptaccess" value="always"></param>'+
			'<embed src="/flash_player10_1/StrobeMediaPlayback.swf" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true"  width="640" height="480" flashvars="src='+video_path+'&autoPlay=true">';

	} else if (video_path.search("mp4")>0)
	{
	// HTML5 Video player
//	 	subtitle_path=video_path.substring(0,video_path.length-3)+'mp4';
//	 	alert(subtitle_path);
		video_path=path+'?token='+g_token;
	//	alert(video_path);
//		str='<video width="640" height="480" src="'+video_path+'" controls autoplay>'+
		str='<video width="640" height="480" controls autoplay>'+
		'<source src="'+video_path+'" type="video/mp4">'+
		'<track src="'+subtitle_path+'" kind="subtitles" srclang="en" label="English">'+
		'</video>';
		

	} else
	{
		video_path=path+'?token='+g_token;
 		if (browser_name.search("Explorer")==0)
 		 {
 		 	//alert(video_path);
 		 	str='<OBJECT id="VIDEO" width="640" height="480" CLASSID="CLSID:6BF52A52-394A-11d3-B153-00C04F79FAA6" type="application/x-oleobject">'+
			'<PARAM NAME="URL" VALUE="'+video_path+'">'+
			'<PARAM NAME="AutoStart" VALUE="True">'+
			'</OBJECT>';
			 
    		}else
		{
			//alert(video_path);
			str='<embed type="application/x-vlc-plugin" width="640" height="480" name="player" autoplay="yes" loop="no" '+
			'target="'+video_path+'">';
		}
	}
	
	
	if (video_path.search("/ch")>0)
	{
		backid.innerHTML='<p align="right"><a style="text-decoration: none" href="ch_pictures.htm"><font face="Arial" color="#FFFFFF" size="2">Back</font></a></p>';
		//time_text_id.innerHTML='<p align="center"><font face="Arial" size="2" color="#FFFF00"><b>Current Time: </b></font></p>';
		backword_button_id.innerHTML='<p align="right"><input type="button" value="<<" onclick="javascript:dvr_for_backward(0);" name="B1" /></p>';
		forward_button_id.innerHTML='<p align="left"><input type="button" value=">>" onclick="javascript:dvr_for_backward(1);" name="B2" /></p>';
		g_current_timestamp=0;
		g_timer=setInterval(function(){show_drv_time_cur_time(0)},1000);
	}else
	{
		backid.innerHTML='<p align="right"><a style="text-decoration: none" href="pictures.htm"><font face="Arial" color="#FFFFFF" size="2">Back</font></a></p>';
	}
	*/
	
	// HTML5 Video player
	video_path=path+'?token='+g_token;
	//alert(video_path);
	if (g_mag_box==0)
	{
		BrowserDetect.init();
		browser_name=BrowserDetect.browser;
		if (browser_name.search("Firefox")==0)
		{
				str='<embed type="application/x-vlc-plugin" width="100%" height="100%" name="player" autoplay="yes" loop="no" '+
				'target="'+video_path+'">';
		}else
		{			
			str='<video width="100%" height="100%" controls autoplay>'+
			'<source src="'+video_path+'" type="video/mp4">'+
			'<track src="'+subtitle_path+'" kind="subtitles" srclang="en" label="English">'+
			'</video>';
		}
		//backid.innerHTML='<p align="right"><a style="text-decoration: none" href="pictures.htm"><font face="Arial" color="#FFFFFF" size="2">Back</font></a></p>';
	
		video_window=document.getElementById("video_area");
	
		//alert(str);
		video_window.innerHTML=str;
	}else
	{
		if (g_bWeb_Menu==1)
		{
			
			stb.SetTopWin(1);
			playstr="ffrt2 "+video_path;
			//stb.SetViewport(300,300,0,0); 
			// Set video screen width, height, left, top
			//stb.Rotate(90);
			stb.Play(playstr);
		}
	}
	


	
 //   flashMovie=getFlashMovieObject("objswf");
 //     flashMovie.pause();
	
	
}


//function dvr_response()
function dvr_for_backward(sign)
{

  	var video_window;
	var path;
	var video_path;
	var browser_name;
	var str;
	var pos1;
	var browser_name;
	var backid=document.getElementById("backword_button_id");
	var to_live_button_id=document.getElementById("to_live_button_id");
	//var time_text_id=document.getElementById("time_text_id");
	var timestamp;
	
	bdvr_on=1;
	//alert(sign);
	//if (xmlHttp.readyState == 4) 
	//{	
	//	var response = xmlHttp.responseText;
		if (sign==0)
		{
			g_dvr_sec-=30*1000;
			forward_button_id.innerHTML='<p align="left"><input type="button" value=">>" onclick="javascript:dvr_for_backward(1);" name="B3" /></p>';

		}
		
		else if (sign==1)
		{
			g_dvr_sec+=30*1000;
			//backword_button_id.innerHTML='<p align="right"><input type="button" value="<<" onclick="javascript:dvr_for_backward(0);" name="B1" /></p>';
		}
		to_live_button_id.innerHTML='<p align="center"><input type="button" value="To Live" onclick="javascript:dvr_to_live();" name="B2" /></p>';

	//	var request_time_stamp;
	//	alert(g_dvr_timestamp);
	//	alert(g_current_timestamp);
		//alert(g_skip_value);
		// FLV
//		request_time_stamp=parseFloat(response)+g_skip_value*1000;
//		g_dvr_timestamp=g_dvr_timestamp+g_skip_value*1000;
		if (g_dvr_sec>g_cur_sec)
		{
			g_dvr_sec=g_cur_sec;
			//forward_button_id.innerHTML='';
			//to_live_button_id.innerHTML='';
			//cur_video_time.innerHTML='';
			//time_text_id.innerHTML='<p align="center"><font face="Arial" size="2" color="#FFFF00"><b>Cur Time</b></font></p>';
			//bdvr_on=0;
		  	video_path=g_video_path;
		} else if (g_dvr_sec<=g_server_dvr_sec)
		{
			g_dvr_sec=g_server_dvr_sec;
			//to_live_button_id.innerHTML='<p align="center"><input type="button" value="To Live" onclick="javascript:dvr_to_live();" name="B2" /></p>';
			//time_text_id.innerHTML='<font face="Arial" size="2" color="#FFFF00"><b>DVR Time: </b></font>';
			//backword_button_id.innerHTML='';
			timestamp=g_dvr_sec-g_server_dvr_sec;
		  	video_path=g_video_path+":timestamp="+timestamp;
		}else
		{
			//to_live_button_id.innerHTML='<p align="center"><input type="button" value="To Live" onclick="javascript:dvr_to_live();" name="B2" /></p>';
			//time_text_id.innerHTML='<font face="Arial" size="2" color="#FFFF00"><b>DVR Time: </b></font>';
			timestamp=g_dvr_sec-g_server_dvr_sec;
		  	video_path=g_video_path+":timestamp="+timestamp;
		}
		
		
		//alert(request_time_stamp);
		//path=find_cookie_value("video_path");
		//g_dvr_timestamp=request_time_stamp;
	  	
	  	
		//alert(path);
	 	//g_user_id=find_cookie_value("userid");
	  	//g_password=find_cookie_value("password");
	
	  	//video_path=path+'?u='+g_user_id+':p='+g_password;
		//g_token=find_cookie_value("token");
	 	//alert(video_path);
	 
	 	BrowserDetect.init();
		browser_name=BrowserDetect.browser;
		if ((browser_name.search("Explorer")==0) || (browser_name.search("Chrome")==0))
		{
				str='<object width="100%" height="100%">'+
				'<param name="allowFullScreen" value="true" />'+
				'<param name="allowscriptaccess" value="always" />'+
				'<embed src="/flash_player10_1/StrobeMediaPlayback.swf" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="100%" height="100%" flashvars="src='+video_path+'&muxer=flv'+'&autoPlay=true">'+ 
				'</embed>'+
				'</object>';	
		}else if (browser_name.search("Safari")==0)
		{
			video_path="http://"+location.hostname+":"+httpport+"/ch"+g_ch_no+".m3u8"+'?token='+g_token+":timestamp="+timestamp+':server_ip_port='+location.hostname+":"+httpport;
			str='<video width="100%" height="100%" src="'+video_path+':server_ip_port='+location.host+':muxer=ts'+'" controls autoplay>';
		}else if (browser_name.search("Firefox")==0)
		{
			str='<embed type="application/x-vlc-plugin" width="100%" height="100%" name="player" autoplay="yes" loop="no" '+
			'target="'+video_path+'">';

		}else
		{
			video_path="http://"+location.hostname+":"+httpport+"/ch"+g_ch_no+".m3u8"+'?token='+g_token+":timestamp="+timestamp+':server_ip_port='+location.hostname+":"+httpport;
			str='<video width="100%" height="100%" src="'+video_path+':server_ip_port='+location.host+':muxer=ts'+'" controls autoplay>';
		}
		
		/*
		if (video_path.search("flv")>0)
		{
			if (browser_name.search("Explorer")==0)
			{
				str='<object width="640" height="480">'+
				'<param name="allowFullScreen" value="true" />'+
				'<param name="allowscriptaccess" value="always" />'+
				'<embed src="/flash_player10_1/StrobeMediaPlayback.swf" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="640" height="480" flashvars="src='+video_path+'&autoPlay=true">'+ 
				'</embed>'+
				'</object>';	
			} else if (browser_name.search("Safari")==0)
			{
		
			}else
			{			
				str='<param name="allowFullScreen" value="true"></param>'+
				'<param name="allowscriptaccess" value="always"></param>'+
				'<embed src="/flash_player10_1/StrobeMediaPlayback.swf" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true"  width="640" height="480" flashvars="src='+video_path+'&autoPlay=true">';
			}
				
						
				
	
		} else if (video_path.search("m3u8")>0)
		{
				str='<video width="640" height="480" src="'+video_path+':server_ip_port='+location.host+'" controls autoplay>';
			
		}else if (video_path.search("ch")>0)
		{
			 if (browser_name.search("Explorer")==0)
	 		 {
	 		 	str='<OBJECT id="VIDEO" width="640" height="480" CLASSID="CLSID:6BF52A52-394A-11d3-B153-00C04F79FAA6" type="application/x-oleobject">'+
				'<PARAM NAME="URL" VALUE="'+video_path+'">'+
				'<PARAM NAME="AutoStart" VALUE="True">'+
				'</OBJECT>';
				 
	    		}else
			{
				str='<embed type="application/x-vlc-plugin" width="640" height="480" name="player" autoplay="yes" loop="no" '+
				'target="'+video_path+'">';
			}	
		}
		*/
		
		if (video_path.search("/ch")>0)
		{
			//backid.innerHTML='<p align="right"><a style="text-decoration: none" href="ch_pictures.htm"><font face="Arial" color="#FFFFFF" size="2">Back</font></a></p>';
			backid.innerHTML='<p align="right"><input type="button" value="<<" onclick="javascript:dvr_for_backward(0);" name="B1" /></p>';
		}else
		{
			backid.innerHTML='<p align="right"><a style="text-decoration: none" href="pictures.htm"><font face="Arial" color="#FFFFFF" size="2">Back</font></a></p>';
		}
		
		video_window=document.getElementById("video_area");
	
		//alert(video_window);
		video_window.innerHTML=str;
		//to_live_button_id.innerHTML='<p align="right"><input type="button" value="To Live" onclick="javascript:dvr_to_live();" name="B2" /></p>';
		//time_text_id.innerHTML='<p align="center"><font face="Arial" size="2" color="#FFFF00"><b>DVR Time</b></font></p>';
	//}

}
function dvr_to_live()
{

  	var video_window;
	var path;
	var video_path;
	var browser_name;
	var str;
	var pos1;
	var browser_name;
	var backid=document.getElementById("backword_button_id");
	//var time_text_id=document.getElementById("time_text_id");
	var cur_video_time=document.getElementById("cur_video_time");
	var timestamp;

	var to_live_button_id=document.getElementById("to_live_button_id");
	bdvr_on=0;
	to_live_button_id.innerHTML='<p align="center"><input type="button" disabled value="To Live" onclick="javascript:dvr_to_live();" name="B2" /></p>';
	forward_button_id.innerHTML='<p align="left"><input type="button" disabled value=">>" onclick="javascript:dvr_for_backward(1);" name="B3" /></p>';
	//if (xmlHttp.readyState == 4) 
	//{	
	//	var response = xmlHttp.responseText;
	

		
	//	alert(request_time_stamp);
		//path=find_cookie_value("video_path");
		g_dvr_sec=g_cur_sec;
		timestamp=g_dvr_sec-g_server_dvr_sec;
		//g_token=find_cookie_value("token");
	  	//video_path=path+'?token='+g_token+":timestamp="+g_dvr_timestamp;
	 	//alert(video_path);
	  	//video_path=g_video_path+":timestamp="+timestamp;
	  	video_path=g_video_path;
	  	//alert(video_path);

	 
	 	BrowserDetect.init();
		browser_name=BrowserDetect.browser;
		if ((browser_name.search("Explorer")==0) || (browser_name.search("Chrome")==0))
		{
			str='<object width="100%" height="100%">'+
			'<param name="allowFullScreen" value="true" />'+
			'<param name="allowscriptaccess" value="always" />'+
			'<embed src="/flash_player10_1/StrobeMediaPlayback.swf" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="100%" height="100%" flashvars="src='+video_path+'muxer=flv'+'&autoPlay=true">'+ 
			'</embed>'+
			'</object>';	
		}else if (browser_name.search("Safari")==0)
		{
			video_path="http://"+location.hostname+":"+httpport+"/ch"+g_ch_no+".m3u8"+'?token='+g_token+':server_ip_port='+location.hostname+":"+httpport;
			str='<video width="100%" height="100%" src="'+video_path+':server_ip_port='+location.host+'muxer=ts'+'" controls autoplay>';
		}else if (browser_name.search("Firefox")==0)
		{
			str='<embed type="application/x-vlc-plugin" width="100%" height="100%" name="player" autoplay="yes" loop="no" '+
			'target="'+video_path+'">';

		}else
		{
			video_path="http://"+location.hostname+":"+httpport+"/ch"+g_ch_no+".m3u8"+'?token='+g_token+':server_ip_port='+location.hostname+":"+httpport;
			str='<video width="100%" height="100%" src="'+video_path+':server_ip_port='+location.host+'muxer=ts'+'" controls autoplay>';
		}
		/*
		if (video_path.search("flv")>0)
		{
			if (browser_name.search("Explorer")==0)
			{
				str='<object width="640" height="480">'+
				'<param name="allowFullScreen" value="true" />'+
				'<param name="allowscriptaccess" value="always" />'+
				'<embed src="/flash_player10_1/StrobeMediaPlayback.swf" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="640" height="480" flashvars="src='+video_path+'&autoPlay=true">'+ 
				'</embed>'+
				'</object>';	
			} else if (browser_name.search("Safari")==0)
			{
		
			}else
			{			
				str='<param name="allowFullScreen" value="true"></param>'+
				'<param name="allowscriptaccess" value="always"></param>'+
				'<embed src="/flash_player10_1/StrobeMediaPlayback.swf" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true"  width="640" height="480" flashvars="src='+video_path+'&autoPlay=true">';
			}
				
						
				
	
		} else if (video_path.search("m3u8")>0)
		{
			if (browser_name.search("Safari")==0)
			{
				str='<video width="640" height="480" src="'+video_path+':server_ip_port='+location.host+'" controls autoplay>';
				//alert(str);
			}
			
		}else if (video_path.search("ch")>0)
		{
			 if (browser_name.search("Explorer")==0)
	 		 {
	 		 	str='<OBJECT id="VIDEO" width="640" height="480" CLASSID="CLSID:6BF52A52-394A-11d3-B153-00C04F79FAA6" type="application/x-oleobject">'+
				'<PARAM NAME="URL" VALUE="'+video_path+'">'+
				'<PARAM NAME="AutoStart" VALUE="True">'+
				'</OBJECT>';
				 
	    		}else
			{
				str='<embed type="application/x-vlc-plugin" width="640" height="480" name="player" autoplay="yes" loop="no" '+
				'target="'+video_path+'">';
			}	
		}
		*/
		if (video_path.search("/ch")>0)
		{
//			backid.innerHTML='<p align="right"><a style="text-decoration: none" href="ch_pictures.htm"><font face="Arial" color="#FFFFFF" size="2">Back</font></a></p>';
			backid.innerHTML='<p align="right"><input type="button" value="<<" onclick="javascript:dvr_for_backward(0);" name="B1" /></p>';
		}else
		{
			backid.innerHTML='<p align="right"><a style="text-decoration: none" href="pictures.htm"><font face="Arial" color="#FFFFFF" size="2">Back</font></a></p>';
		}
		
		video_window=document.getElementById("video_area");
	
		//alert(str);
		video_window.innerHTML=str;
		//to_live_button_id.innerHTML='';
		//time_text_id.innerHTML='<font face="Arial" size="2" color="#FFFF00"><b>Current Time: </b></font>';
		cur_video_time.innerHTML='';
		dvr_video_time.innerHTML='';
		//forward_button_id.innerHTML='';
	//}

}
/*
function dvr_for_backward(sign)
{
	//g_skip_value = parseInt(sign+document.getElementById("skip_value_id").value);
	g_skip_value = parseInt(sign+"10");

  	g_token=find_cookie_value("token");
    	cgi_url= "/player/query_player_timestamp?token="+escape(g_token)+"&flag="+Math.random();

	xmlHttp.open("GET", cgi_url, true);
	xmlHttp.onreadystatechange =dvr_response ;
	xmlHttp.send(null);
}
*/
/*
function init_video()
{
	var video_window;
	var path;
	var video_path;
	var browser_name;
	var str;
	var pos1;
	var browser_name;
	var backid=document.getElementById("back");
	
//	video_path=path.substring(43,path.length-11)+'?u=root&p=1234';
	
  	path=find_cookie_value("video_path");
  	
  	
	//alert(path);
 	//g_user_id=find_cookie_value("userid");
  	//g_password=find_cookie_value("password");

  	//video_path=path+'?u='+g_user_id+':p='+g_password;
	g_token=find_cookie_value("token");
  	video_path=path+'?token='+g_token;
 	//alert(video_path);
 
	str='<object width="720" height="480">'+
	'<param name="allowFullScreen" value="true" />'+
	'<param name="allowscriptaccess" value="always" />'+
	'<embed src="/flash_player10_1/StrobeMediaPlayback.swf" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="720" height="480" flashvars="src='+video_path+'">'+ 
	'</embed>'+
	'</object>';	
	
//	str+='<param name="allowFullScreen" value="true"></param>'+
//	'<param name="allowscriptaccess" value="always"></param>'+
//	'<embed src="/flash_player10_1/StrobeMediaPlayback.swf" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true"  width="720" height="480" flashvars="src='+video_path+'">';
	
//	str+='<source src="'+video_path+'" />';
	str+='<source src="'+video_path+'&server_ip_port='+location.host+'" />';
	
	if (video_path.search("/ch")>0)
	{
		backid.innerHTML='<p align="right"><a style="text-decoration: none" href="ch_pictures.htm"><font face="Arial" color="#FFFFFF" size="2">Back</font></a></p>';
	}else
	{
		backid.innerHTML='<p align="right"><a style="text-decoration: none" href="pictures.htm"><font face="Arial" color="#FFFFFF" size="2">Back</font></a></p>';
	}
	
	video_window=document.getElementById("video_window");

	//alert(str);
	video_window.innerHTML='<video controls width="640" height="480">'+str+'</video>';
	video_control_init();
	
	
}
*/
/*
function dvr_for_backward(sign)
{
	var skip_value = document.getElementById("skip_value_id").value;
	var video_time=document.getElementById("video_time");

  	var video_window;
	var path;
	var video_path;
	var browser_name;
	var str;
	var pos1;
	var browser_name;
	var backid=document.getElementById("back");
	
	path=find_cookie_value("video_path");
  	
  	
	//alert(path);
 	//g_user_id=find_cookie_value("userid");
  	//g_password=find_cookie_value("password");

  	//video_path=path+'?u='+g_user_id+':p='+g_password;
	g_token=find_cookie_value("token");
  	video_path=path+'?token='+g_token+":skip="+sign+skip_value;
 	//alert(video_path);
   	//cgi_url= "/server/inquery_server_ip_htpport?token="+escape(g_token)+"&flag="+Math.random();

	xmlHttp.open("GET", video_path, true);
	//xmlHttp.onreadystatechange =play_video ;
	xmlHttp.send(null);
	video_time.innerHTML='<p align="right"><font face="Arial" size="2" color="#FFFF00"><b>DVR</b></font>';

 

}
*/